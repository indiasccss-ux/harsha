package com.example.myapplication

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.util.Log
import kotlinx.coroutines.*
import java.util.concurrent.ConcurrentLinkedQueue

/**
 * StreamingAudioPlayer — plays 16-kHz PCM chunks in real time.
 * Plays chunk N while pipeline processes chunk N+1 (double buffering).
 * Queue capped at 10 chunks (~20 s) to prevent OOM on long videos.
 */
class StreamingAudioPlayer {
    private val TAG = "StreamingAudioPlayer"
    private val SR = 16000
    private val minBuf = AudioTrack.getMinBufferSize(SR,
        AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT).coerceAtLeast(8192)
    private var track: AudioTrack? = null
    private val queue = ConcurrentLinkedQueue<ByteArray>()
    @Volatile private var running = false
    private var job: Job? = null

    fun play() {
        if (running) return
        track = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(AudioFormat.Builder().setSampleRate(SR)
                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT).build())
            .setBufferSizeInBytes(minBuf).setTransferMode(AudioTrack.MODE_STREAM).build()
        track?.play(); running = true
        job = CoroutineScope(Dispatchers.IO).launch {
            while (running) {
                val chunk = queue.poll()
                if (chunk != null) { val r = track?.write(chunk, 0, chunk.size) ?: 0; if (r<0) Log.e(TAG,"write $r") }
                else delay(10)
            }
        }
        Log.i(TAG, "Started")
    }

    fun write(data: ByteArray) {
        if (!running || data.isEmpty()) return
        while (queue.size >= 10) queue.poll()
        queue.offer(data)
    }

    fun release() {
        running = false; job?.cancel()
        runCatching { track?.stop(); track?.release() }
        track = null; queue.clear(); Log.i(TAG, "Released")
    }
}
