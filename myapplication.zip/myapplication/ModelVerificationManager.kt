package com.example.myapplication

import android.content.Context
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

import com.example.myapplication.core.ModelManager
import com.example.myapplication.core.VoiceProfile
import com.example.myapplication.core.Emotion

/**
 * ModelVerificationManager - Phase-10 Hardening.
 * Ensures all AI models load and execute at least one safe inference.
 */
class ModelVerificationManager(private val context: Context) {
    private val TAG = "MODEL_VERIFICATION"
    
    private val modelSwapper get() = ModelManager.modelSwapper
    private val inferenceEngine get() = ModelManager.sharedInferenceEngine
    
    suspend fun verifyAllModels() = withContext(Dispatchers.Default) {
        Log.i(TAG, "Starting Global AI Model Verification...")
        verifyWhisperSTT()
        verifyTTSCloning()
        verifyLatentSync()
        verifyDemucsNano()
        verifyRealESRANTernary()
        Log.i(TAG, "Global AI Model Verification Complete.")
    }

    private suspend fun verifyWhisperSTT() {
        Log.d(TAG, "Verifying WhisperSTT (On-Device)...")
        try {
            val stt = ModelManager.getWhisper(context)
            stt.initialize(true)
            
            // Generate non-silent audio (simple tone)
            val sampleRate = 16000
            val duration = 1.0 // second
            val numSamples = (sampleRate * duration).toInt()
            val dummyAudio = ByteArray(numSamples * 2) 
            for (i in 0 until numSamples) {
                val sample = (32767 * Math.sin(2.0 * Math.PI * 440.0 * i / sampleRate)).toInt().toShort()
                dummyAudio[i * 2] = (sample.toInt() and 0xff).toByte()
                dummyAudio[i * 2 + 1] = ((sample.toInt() shr 8) and 0xff).toByte()
            }
            
            // Pass raw PCM directly (WhisperSTT expects 16kHz Mono)
            val segmentsResult = stt.transcribe(dummyAudio)
            val segments = segmentsResult.getOrNull() ?: emptyList()
            Log.i(TAG, "WhisperSTT: SUCCESS. Produced ${segments.size} segments.")
        } catch (e: Throwable) {
            Log.e(TAG, "WhisperSTT: FAILED - ${e.message}")
        }
    }

    private suspend fun verifyTTSCloning() {
        Log.d(TAG, "Verifying KokoroTTS/Cloning...")
        try {
            val kokoro = ModelManager.getKokoro(context)
            val cloned = ModelManager.getClonedEngine(context)
            
            // Text to speech
            val audio = kokoro.speak(
                text = "Verification test.",
                profile = VoiceProfile.NEUTRAL,
                emotion = Emotion.NEUTRAL,
                intensity = 1.0f
            )
            
            // Voice cloning (if possible with neutral)
            val profile = VoiceProfile("test_speaker", "Test", isCloned = true, readinessScore = 100)
            val clonedAudio = cloned.speak(
                text = "Cloning test.",
                profile = profile,
                emotion = Emotion.NEUTRAL,
                intensity = 1.0f
            )
            
            Log.i(TAG, "KokoroTTS/Cloning: SUCCESS. Audio sizes: ${audio.size}, ${clonedAudio.size}")
        } catch (e: Throwable) {
            Log.e(TAG, "KokoroTTS/Cloning: FAILED - ${e.message}")
        }
    }

    private suspend fun verifyLatentSync() {
        Log.d(TAG, "Verifying LatentSync...")
        try {
            val lipsync = ModelManager.getLipSync(context)
            
            // Dummy mouth crop (96x96 RGB)
            val mouthCrop = java.nio.ByteBuffer.allocateDirect(96 * 96 * 3).order(java.nio.ByteOrder.nativeOrder())
            val audioFeature = FloatArray(80) 
            
            val output = lipsync.syncLips(mouthCrop, audioFeature, Emotion.NEUTRAL)
            Log.i(TAG, "LatentSync: SUCCESS. Output buffer capacity: ${output.capacity()}")
        } catch (e: Throwable) {
            Log.e(TAG, "LatentSync: FAILED - ${e.message}")
        }
    }

    private suspend fun verifyDemucsNano() {
        Log.d(TAG, "Verifying DemucsNano (Voice Isolation)...")
        try {
            val demucs = ModelManager.getDemucs(context)
            val dummyAudio = ByteArray(32000 * 2) // 2 seconds
            val stems = demucs.separateStems(dummyAudio)
            Log.i(TAG, "DemucsNano: SUCCESS. Vocals size: ${stems.vocals.size}, BGM size: ${stems.bgm.size}")
        } catch (e: Throwable) {
            Log.e(TAG, "DemucsNano: FAILED - ${e.message}")
        }
    }

    private suspend fun verifyRealESRANTernary() {
        Log.d(TAG, "Verifying RealESRANTernary (Upscaling)...")
        try {
            val upscaler = ModelManager.getUpscaler(context)
            
            // Dummy frame (Match model input tensor [1, 128, 128, 3] to avoid resize overhead)
            val frame = java.nio.ByteBuffer.allocateDirect(128 * 128 * 3).order(java.nio.ByteOrder.nativeOrder())
            val output = upscaler.upscale(frame, 0)
            Log.i(TAG, "RealESRGAN: SUCCESS. Output buffer capacity: ${output.capacity()}")
        } catch (e: Throwable) {
            Log.e(TAG, "RealESRGAN: FAILED - ${e.message}")
        }
    }
}
