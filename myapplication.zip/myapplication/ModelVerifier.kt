// ...existing code...
package com.example.myapplication

import android.content.Context
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.nio.ByteBuffer
import java.nio.ByteOrder
import com.example.myapplication.core.ModelManager
import com.example.myapplication.core.VoiceProfile
import com.example.myapplication.core.Emotion

object ModelVerifier {
    private const val TAG = "MODEL_VERIFIER"

    // Run lightweight checks for each major model/component. Returns map of component -> status message
    suspend fun runAll(context: Context): Map<String, String> = withContext(Dispatchers.Default) {
        val results = mutableMapOf<String, String>()

        // 1) Asset presence
        try {
            val assets = ModelChecker.checkAssets(context)
            for ((k, v) in assets) {
                results["asset:$k"] = if (v) "present" else "missing"
            }
        } catch (e: Exception) {
            Log.e(TAG, "Asset check failed: ${e.message}")
        }

        // 2) Whisper STT
        try {
            val stt = ModelManager.getWhisper(context)
            stt.initialize()
            // simple tone
            val sampleRate = 16000
            val duration = 0.5
            val numSamples = (sampleRate * duration).toInt()
            val dummyAudio = ByteArray(numSamples * 2)
            for (i in 0 until numSamples) {
                val s = ( (32767 * Math.sin(2.0 * Math.PI * 440.0 * i / sampleRate)).toInt() and 0xffff ).toShort()
                dummyAudio[i * 2] = (s.toInt() and 0xff).toByte()
                dummyAudio[i * 2 + 1] = ((s.toInt() shr 8) and 0xff).toByte()
            }
            val res = stt.transcribe(dummyAudio)
            if (res.isSuccess) {
                results["WhisperSTT"] = "ok"
            } else {
                results["WhisperSTT"] = "failed: ${res.exceptionOrNull()?.message ?: "no segments"}"
            }
        } catch (e: Throwable) {
            results["WhisperSTT"] = "error: ${e.message}"
        }

        // 3) KokoroTTS (Android fallback)
        try {
            val kokoro = ModelManager.getKokoro(context)
            val wav = kokoro.speak("Verification Test.", VoiceProfile.NEUTRAL, Emotion.NEUTRAL, 1.0f)
            results["KokoroTTS"] = if (wav.isNotEmpty()) "ok" else "empty-result"
        } catch (e: Throwable) {
            results["KokoroTTS"] = "error: ${e.message}"
        }

        // 4) ClonedVocalEngine (may fallback)
        try {
            val kokoro = ModelManager.getKokoro(context)
            val cloned = ModelManager.getClonedEngine(context)
            val profile = VoiceProfile("verifier", "Verifier", isCloned = true, readinessScore = 100)
            val out = cloned.speak("Cloning test.", profile, Emotion.NEUTRAL, 1.0f)
            results["ClonedVocalEngine"] = if (out.isNotEmpty()) "ok" else "empty-result"
        } catch (e: Throwable) {
            results["ClonedVocalEngine"] = "error: ${e.message}"
        }

        // 5) DemucsNano (separation)
        try {
            val demucs = ModelManager.getDemucs(context)
            // Empty silence test
            val dummyAudio = ByteArray(16000 * 2) // 1s
            val stems = demucs.separateStems(dummyAudio)
            results["DemucsNano"] = if (stems.vocals.isNotEmpty() || stems.bgm.isNotEmpty()) "ok/fallback" else "ok/unchanged"
        } catch (e: Throwable) {
            results["DemucsNano"] = "error: ${e.message}"
        }

        // 6) LatentSyncMicro
        try {
            val lipsync = ModelManager.getLipSync(context)
            val mouth = ByteBuffer.allocateDirect(96 * 96 * 3).order(ByteOrder.nativeOrder())
            val audioFeature = FloatArray(80)
            val out = lipsync.syncLips(mouth, audioFeature, Emotion.NEUTRAL)
            results["LatentSyncMicro"] = "ok (out cap=${out.capacity()})"
        } catch (e: Throwable) {
            results["LatentSyncMicro"] = "error: ${e.message}"
        }

        // 7) RealESRANTernary
        try {
            val up = ModelManager.getUpscaler(context)
            val frame = ByteBuffer.allocateDirect(128 * 128 * 3).order(ByteOrder.nativeOrder())
            val out = up.upscale(frame, 0)
            results["RealESRANTernary"] = "ok (out cap=${out.capacity()})"
        } catch (e: Throwable) {
            results["RealESRANTernary"] = "error: ${e.message}"
        }

        results.toMap()
    }
}
