package com.example.myapplication

import android.content.Context
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import com.example.myapplication.core.Emotion

/**
 * BGM & SFX Engine (Phase-6).
 * Orchestrates background music and sound effects synced to character emotions.
 * Maintains zero-cost, strictly on-device processing.
 */
class BgmSfxEngine(private val context: Context) {
    private val TAG = "BgmSfxEngine"

    data class BgmState(
        val fileName: String,
        val intensity: Float, // 0.0 to 1.0 (Mapped from Emotion intensity)
        val loop: Boolean = true
    )

    private var isInitialized = false

    /**
     * Non-blocking warmup for background preloading.
     */
    fun warmup() {
        if (isInitialized) return
        CoroutineScope(Dispatchers.IO).launch {
            try {
                // Pre-verify BGM asset availability
                val testFile = "neutral_background.wav"
                // Checking existence without full read
                context.assets.open("audio/bgm/$testFile").use { it.close() }
                isInitialized = true
                Log.d(TAG, "BGM Engine primed and assets verified.")
            } catch (e: Exception) {
                Log.e(TAG, "BGM warmup fallback: assets missing")
            }
        }
    }

    /**
     * Resolves the appropriate BGM state based on the current emotion and its intensity.
     */
    fun resolveBgm(emotion: Emotion, intensity: Float): BgmState {
        return when (emotion) {
            Emotion.HAPPY -> BgmState("uplifting_beat.wav", intensity * 0.8f)
            Emotion.SAD -> BgmState("melancholic_piano.wav", intensity * 0.6f)
            Emotion.ANGRY -> BgmState("tense_strings.wav", intensity * 1.0f)
            Emotion.WHISPER -> BgmState("soft_ambience.wav", 0.3f)
            Emotion.FEAR -> BgmState("dark_ominous.wav", intensity * 1.2f)
            Emotion.SURPRISE -> BgmState("stings_high_freq.wav", intensity * 0.9f)
            else -> BgmState("neutral_background.wav", 0.4f)
        }
    }

    fun resolveSfxIntensity(isActionScene: Boolean): Float {
        return if (isActionScene) 1.0f else 0.5f
    }
    
    fun release() {
        Log.i(TAG, "Releasing BGM Engine resources.")
    }

    fun getSfxForText(text: String): String? {
        val lower = text.lowercase()
        return when {
            lower.contains("laugh") || lower.contains("haha") -> "laugh_sfx.wav"
            lower.contains("door") || lower.contains("knock") -> "door_knock.wav"
            lower.contains("car") || lower.contains("drive") -> "car_passby.wav"
            lower.contains("bird") || lower.contains("nature") -> "birds_chirping.wav"
            else -> null
        }
    }

    fun getDuckingRecommendation(isActionScene: Boolean): Float {
        return if (isActionScene) 0.6f else 0.3f
    }

    fun getBgmSamples(fileName: String): ByteArray {
        return try {
            val inputStream = context.assets.open("audio/bgm/$fileName")
            val bytes = inputStream.readBytes()
            inputStream.close()
            bytes
        } catch (e: Exception) {
            Log.w(TAG, "BGM file not found: $fileName. Using silence.")
            ByteArray(0)
        }
    }
}
