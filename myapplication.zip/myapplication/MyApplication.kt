package com.example.myapplication

import android.app.Application
import android.util.Log

/**
 * MyApplication: App Entry Point.
 * Triggers background preloading of exhaustive AI models on startup.
 */
class MyApplication : Application() {
    private val TAG = "MyApplication"

    override fun onCreate() {
        super.onCreate()
        Log.i(TAG, "Application created. AI Environment set to Lazy Mode.")
        
        // Phase-10: Preloading moved to on-demand (ModelManager.loadDubbingModels)
    }
}
