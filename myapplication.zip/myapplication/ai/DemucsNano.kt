package com.example.myapplication.ai

import android.content.Context
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * The Sound: Demucs-Nano (1.58-bit Ternary).
 * Performs 4-stem audio separation to isolate Vocals for dubbing
 * while preserving SFX (punches, clashes) and BGM.
 */
class DemucsNano(
    private val context: Context,
    private val modelSwapper: ModelSwapper,
    private val inferenceEngine: InferenceEngine
) {

    private val MODEL_ASSET = "demucs-nano.tflite"

    data class AudioStems(
        val vocals: ByteArray,
        val bgm: ByteArray,
        val sfx: ByteArray,
        val other: ByteArray
    )

    private var isInitialized = false

    /**
     * Non-blocking warmup for background preloading.
     */
    fun warmup() {
        if (isInitialized) return
        CoroutineScope(Dispatchers.IO).launch {
            try {
                // Check asset availability
                val assetList = context.assets.list("")
                if (assetList?.contains(MODEL_ASSET) != true) {
                    Log.w("DemucsNano", "Model asset $MODEL_ASSET not found. Demucs disabled.")
                    return@launch
                }

                // Trigger model swap and audit
                modelSwapper.swapTo(ModelSwapper.ModelState.SOUND, MODEL_ASSET)
                val buffer = modelSwapper.getCurrentBuffer()
                if (buffer != null) {
                    inferenceEngine.initialize(buffer)
                    isInitialized = true
                    Log.d("DemucsNano", "Warmup successful: Model ready.")
                }
            } catch (e: Exception) {
                Log.e("DemucsNano", "Warmup failed")
            }
        }
    }

    suspend fun separateStems(inputAudio: ByteArray): AudioStems {
        Log.d("DemucsNano", "Separating audio: ${inputAudio.size} bytes")
        if (inputAudio.isEmpty()) {
            return AudioStems(ByteArray(0), ByteArray(0), ByteArray(0), ByteArray(0))
        }

        // Check asset availability (Safe Fallback)
        val assetList = context.assets.list("")
        if (assetList?.contains(MODEL_ASSET) != true) {
            Log.w("DemucsNano", "Demucs model missing. Using Voice-Over mode (Original Audio as BGM).")
            // Fallback: Return original audio as BGM (Voice Over style)
            // Vocals empty so we don't double-process
            return AudioStems(ByteArray(0), inputAudio, ByteArray(0), ByteArray(0))
        }

        // 1. Swap Model to Sound
        modelSwapper.swapTo(ModelSwapper.ModelState.SOUND, MODEL_ASSET)
        val buffer = modelSwapper.getCurrentBuffer() ?: throw IllegalStateException("Demucs model buffer missing.")
        
        Log.i("DemucsNano", "✅ SOUND MODEL ACTIVE: Isolating Vocals...")
        inferenceEngine.initialize(buffer)

        // 2. Chunking Logic
        val BYTES_PER_SEC = 32000
        val CHUNK_DURATION_SEC = 10
        val CHUNK_SIZE = CHUNK_DURATION_SEC * BYTES_PER_SEC

        val vocalsOut = java.io.ByteArrayOutputStream()
        val bgmOut = java.io.ByteArrayOutputStream()
        val sfxOut = java.io.ByteArrayOutputStream()
        val otherOut = java.io.ByteArrayOutputStream()

        var offset = 0
        while (offset < inputAudio.size) {
            val remaining = inputAudio.size - offset
            val currentChunkSize = if (remaining < CHUNK_SIZE) remaining else CHUNK_SIZE
            val chunkBytes = ByteArray(currentChunkSize)
            System.arraycopy(inputAudio, offset, chunkBytes, 0, currentChunkSize)

            // Process this chunk
            val (v, b, s, o) = processSingleChunk(chunkBytes)
            vocalsOut.write(v)
            bgmOut.write(b)
            sfxOut.write(s)
            otherOut.write(o)

            offset += currentChunkSize
        }

        return AudioStems(
            vocals = vocalsOut.toByteArray(),
            bgm = bgmOut.toByteArray(),
            sfx = sfxOut.toByteArray(),
            other = otherOut.toByteArray()
        )
    }

    private fun processSingleChunk(inputChunk: ByteArray): AudioStems {
        val inputBuffer = java.nio.ByteBuffer.allocateDirect(inputChunk.size)
        inputBuffer.order(java.nio.ByteOrder.nativeOrder())
        inputBuffer.put(inputChunk)
        inputBuffer.rewind()

        val outputs = mutableMapOf<Int, Any>()
        for (i in 0 until 4) {
             val buf = java.nio.ByteBuffer.allocateDirect(inputChunk.size)
             buf.order(java.nio.ByteOrder.nativeOrder())
             outputs[i] = buf
        }

        try {
            inferenceEngine.run(inputs = arrayOf(inputBuffer), outputs = outputs)
        } catch (e: Exception) {
            Log.e("DemucsNano", "Chunk inference failed: ${e.message}")
            return AudioStems(ByteArray(inputChunk.size), ByteArray(inputChunk.size), ByteArray(inputChunk.size), ByteArray(inputChunk.size))
        }

        fun getBytes(index: Int): ByteArray {
            val buf = outputs[index] as java.nio.ByteBuffer
            buf.rewind()
            val arr = ByteArray(buf.remaining())
            buf.get(arr)
            return arr
        }

        val rawVocals = getBytes(0)
        val stems1 = getBytes(1)
        val stems3 = getBytes(3)
        
        val bgm = ByteArray(inputChunk.size)
        for(i in bgm.indices) {
            val s1 = stems1.getOrElse(i) {0}.toInt()
            val s3 = stems3.getOrElse(i) {0}.toInt()
            var sum = s1 + s3
            bgm[i] = sum.coerceIn(-128, 127).toByte()
        }

        return AudioStems(rawVocals, bgm, stems1, stems3)
    }
}
