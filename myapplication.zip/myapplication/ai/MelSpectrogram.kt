package com.example.myapplication.ai

import kotlin.math.*

/** Whisper-spec log-Mel extractor: n_fft=400, hop=160, n_mels=80, sr=16000. */
object MelSpectrogram {
    private const val SR=16000; private const val N_FFT=400; private const val HOP=160
    private const val N_MELS=80; private const val FMAX=8000f; private const val FLOOR=-11.5f
    private val window: FloatArray; private val filters: Array<FloatArray>; private val fftSz: Int
    init {
        window = FloatArray(N_FFT) { n ->
            (0.5 * (1.0 - cos(2.0 * PI * n / (N_FFT - 1)))).toFloat()
        }
        var s = 1
        while (s < N_FFT) {
            s = s shl 1
        }
        fftSz = s
        filters = buildFilters()
    }

    fun compute(audio: FloatArray): FloatArray {
        val nf = maxOf(1, (audio.size - N_FFT) / HOP + 1)
        val out = FloatArray(N_MELS * nf)
        val re = FloatArray(fftSz)
        val im = FloatArray(fftSz)
        val ps = FloatArray(N_FFT / 2 + 1)

        for (f in 0 until nf) {
            val s = f * HOP
            re.fill(0f)
            im.fill(0f)
            for (i in 0 until N_FFT) {
                re[i] = if (s + i < audio.size) audio[s + i] * window[i] else 0f
            }
            fft(re, im)
            for (k in 0..N_FFT / 2) {
                val r = re[k]
                val i = im[k]
                ps[k] = r * r + i * i
            }
            for (m in 0 until N_MELS) {
                var e = 0f
                val fl = filters[m]
                for (k in fl.indices) {
                    e += fl[k] * ps[k]
                }
                out[f * N_MELS + m] = maxOf(ln(maxOf(e, 1e-10f).toDouble()).toFloat(), FLOOR)
            }
        }
        return out
    }

    private fun fft(re: FloatArray, im: FloatArray) {
        val n = re.size
        var j = 0
        for (i in 1 until n) {
            var b = n shr 1
            while (j and b != 0) {
                j = j xor b
                b = b shr 1
            }
            j = j xor b
            if (i < j) {
                val tempR = re[i]
                re[i] = re[j]
                re[j] = tempR
                val tempI = im[i]
                im[i] = im[j]
                im[j] = tempI
            }
        }
        var len = 2
        while (len <= n) {
            val h = len / 2
            val ang = -2.0 * PI / len
            val wR = cos(ang).toFloat()
            val wI = sin(ang).toFloat()
            var i = 0
            while (i < n) {
                var uR = 1f
                var uI = 0f
                for (k in 0 until h) {
                    val tR = uR * re[i + k + h] - uI * im[i + k + h]
                    val tI = uR * im[i + k + h] + uI * re[i + k + h]
                    re[i + k + h] = re[i + k] - tR
                    im[i + k + h] = im[i + k] - tI
                    re[i + k] += tR
                    im[i + k] += tI
                    val nU = uR * wR - uI * wI
                    uI = uR * wI + uI * wR
                    uR = nU
                }
                i += len
            }
            len = len shl 1
        }
    }

    private fun buildFilters(): Array<FloatArray> {
        val nF = N_FFT / 2 + 1
        fun h2m(hz: Float) = 2595f * log10(1f + hz / 700f)
        fun m2h(m: Float) = 700f * (10f.pow(m / 2595f) - 1f)
        val lo = h2m(0f)
        val hi = h2m(FMAX)
        val pts = FloatArray(N_MELS + 2) { m -> m2h(lo + m * (hi - lo) / (N_MELS + 1)) }
        val bins = IntArray(N_MELS + 2) { m -> ((pts[m] / (SR / 2f)) * nF).toInt().coerceIn(0, nF - 1) }
        return Array(N_MELS) { m ->
            FloatArray(nF).also { f ->
                val l = bins[m]
                val c = bins[m + 1]
                val r = bins[m + 2]
                for (k in l until c) {
                    if (c != l) f[k] = (k - l).toFloat() / (c - l)
                }
                for (k in c until r) {
                    if (r != c) f[k] = (r - k).toFloat() / (r - c)
                }
            }
        }
    }
}
