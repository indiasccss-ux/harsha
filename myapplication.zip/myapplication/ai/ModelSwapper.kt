package com.example.myapplication.ai

import android.content.Context
import android.util.Log
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.channels.FileChannel

/**
 * State-Based Model Swapper for NPU Edge-Inference.
 * Handles zero-copy Memory-Mapped (mmap) loading to maintain 450MB RAM footprint.
 */
class ModelSwapper(private val context: Context) {

    enum class ModelState {
        IDLE,
        STT,         // Moonshine-Tiny
        TRANSLATION, // Gemma-2-2B (Bhasha-Rupantarika)
        SOUND,       // Demucs-Nano
        TTS,         // Kokoro-82M
        SPEECH,      // Kokoro-82M (Cloning)
        LIP_SYNC,    // LatentSync-Micro
        UPSCALING    // Real-ESRGAN-Ternary
    }

    private var currentState = ModelState.IDLE
    private var currentModelBuffer: java.nio.ByteBuffer? = null

    /**
     * Cycles the active model in RAM.
     * Tries user-provided files (app files dir) first, then assets. Uses direct ByteBuffer so Interpreter can accept it.
     */
    fun swapTo(state: ModelState, modelAssetName: String) {
        if (state == currentState) return

        Log.d("ModelSwapper", "Swapping state: $currentState -> $state")
        releaseCurrentModel()

        // Try user-provided model in filesDir/models/
        try {
            val userDir = java.io.File(context.filesDir, "models")
            val userFile = java.io.File(userDir, modelAssetName)
            if (userFile.exists()) {
                Log.d("ModelSwapper", "Loading model from filesDir: ${userFile.absolutePath}")
                val fis = FileInputStream(userFile)
                val fc = fis.channel
                val mapped = fc.map(FileChannel.MapMode.READ_ONLY, 0, fc.size())
                fc.close()
                fis.close()
                currentModelBuffer = mapped
                currentState = state
                Log.d("ModelSwapper", "Model ${userFile.name} mapped from filesDir. State: $currentState")
                return
            }
        } catch (e: Exception) {
            Log.w("ModelSwapper", "Failed to load from filesDir: ${e.message}")
        }

        // 2. Load the new model via mmap from assets
        try {
            val assetFileDescriptor = context.assets.openFd(modelAssetName)
            val inputStream = FileInputStream(assetFileDescriptor.fileDescriptor)
            val fileChannel = inputStream.channel

            currentModelBuffer = fileChannel.map(
                FileChannel.MapMode.READ_ONLY,
                assetFileDescriptor.startOffset,
                assetFileDescriptor.length
            )

            fileChannel.close()
            inputStream.close()
            assetFileDescriptor.close()

            currentState = state
            Log.d("ModelSwapper", "Model $modelAssetName mapped successfully from assets. State: $currentState")
            return
        } catch (e: Exception) {
            Log.e("ModelSwapper", "Failed to mmap model $modelAssetName from assets: ${e.message}")
            // Fallback: try direct load
            tryLoadDirect(modelAssetName)
            currentState = state
        }
    }

    private fun tryLoadDirect(name: String) {
        try {
            // First check filesDir fallback
            val userDir = java.io.File(context.filesDir, "models")
            val userFile = java.io.File(userDir, name)
            if (userFile.exists()) {
                val bytes = userFile.readBytes()
                val direct = ByteBuffer.allocateDirect(bytes.size)
                direct.order(java.nio.ByteOrder.nativeOrder())
                direct.put(bytes)
                direct.rewind()
                currentModelBuffer = direct
                Log.w("ModelSwapper", "Loaded model $name from filesDir into direct ByteBuffer.")
                return
            }

            // Fallback to assets bytes
            val bytes = context.assets.open(name).use { it.readBytes() }
            val direct = ByteBuffer.allocateDirect(bytes.size)
            direct.order(java.nio.ByteOrder.nativeOrder())
            direct.put(bytes)
            direct.rewind()
            currentModelBuffer = direct
            Log.w("ModelSwapper", "Zero-copy failed for $name. Loaded into direct ByteBuffer.")
        } catch (e: Exception) {
            Log.e("ModelSwapper", "Direct load also failed for $name: ${e.message}")
        }
    }

    private fun releaseCurrentModel() {
        currentModelBuffer = null
        currentState = ModelState.IDLE
        System.gc()
    }

    fun getCurrentBuffer(): java.nio.ByteBuffer? = currentModelBuffer
    fun getCurrentState(): ModelState = currentState
}
