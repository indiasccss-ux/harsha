package com.example.myapplication.ai

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import com.example.myapplication.core.IVocalEngine
import com.example.myapplication.core.VoiceProfile
import com.example.myapplication.core.Emotion
import com.example.myapplication.core.EmotionParameterMap

/**
 * KokoroTTS
 * REAL: Android TTS → WAV → 16 kHz mono PCM with prosody from EmotionParameterMap.
 * PLANNED: Neural Kokoro-82M TFLite upgrade (needs kokoro-82m.tflite in assets).
 */
class KokoroTTS(private val context: Context) : IVocalEngine {
    private val TAG = "KokoroTTS"
    private var tts: TextToSpeech? = null
    @Volatile private var ready = false
    private val lock = Object()
    init { warmup() }

    fun warmup() {
        if (ready) return
        android.os.Handler(android.os.Looper.getMainLooper()).post {
            tts = TextToSpeech(context) { s ->
                synchronized(lock) { ready=(s==TextToSpeech.SUCCESS); lock.notifyAll()
                    if (ready) Log.i(TAG,"TTS ready") else Log.e(TAG,"TTS init failed $s") }
            }
        }
    }

    private fun await(ms:Long=6000):Boolean {
        if(ready) return true
        synchronized(lock){ val dl=System.currentTimeMillis()+ms
            while(!ready){ val r=dl-System.currentTimeMillis(); if(r<=0) return false; lock.wait(r) } }
        return ready
    }

    override suspend fun speak(text:String, profile:VoiceProfile, emotion:Emotion, intensity:Float): ByteArray =
        withContext(Dispatchers.IO) {
        if(!await()) throw IllegalStateException("Android TTS not ready")
        val p=EmotionParameterMap.getProsody(emotion)
        tts?.setPitch((1f+(p.pitchMultiplier-1f)*intensity).coerceIn(0.5f,2f))
        tts?.setSpeechRate((1f+(p.rateMultiplier-1f)*intensity).coerceIn(0.5f,2f))
        val lr=tts?.setLanguage(speakerLocale(profile.speakerId))
        if(lr==TextToSpeech.LANG_MISSING_DATA||lr==TextToSpeech.LANG_NOT_SUPPORTED) tts?.setLanguage(Locale.US)
        val wav=synth(text)
        if(wav.size<=44){ Log.e(TAG,"Empty TTS for: ${text.take(40)}"); return@withContext ByteArray(0) }
        val pcm=wavTo16k(wav)
        Log.i(TAG,"TTS \"${text.take(50)}\" → ${pcm.size}B 16kHz")
        pcm
    }

    private fun synth(text:String): ByteArray {
        val tmp=File.createTempFile("tts_",".wav",context.cacheDir)
        val l=CountDownLatch(1); var ok=false
        tts?.setOnUtteranceProgressListener(object:UtteranceProgressListener(){
            override fun onStart(id:String?){}
            override fun onDone(id:String?){ok=true;l.countDown()}
            @Deprecated("") override fun onError(id:String?){l.countDown()}
            override fun onError(id:String?,code:Int){l.countDown()}
        })
        val uid="u${System.currentTimeMillis()}"
        tts?.synthesizeToFile(text,android.os.Bundle().also{it.putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID,uid)},tmp,uid)
        l.await(10,TimeUnit.SECONDS)
        return if(ok&&tmp.exists()) tmp.readBytes().also{tmp.delete()} else ByteArray(0).also{tmp.delete()}
    }

    private fun wavTo16k(wav:ByteArray): ByteArray {
        if(wav.size<44) return ByteArray(0)
        val h=ByteBuffer.wrap(wav,0,44).order(ByteOrder.LITTLE_ENDIAN)
        h.position(22); val ch=h.short.toInt(); h.position(24); val sr=h.int; h.position(34); val bps=h.short.toInt()
        val bpS=bps/8; if(bpS==0||ch==0) return ByteArray(0)
        val pcm=wav.copyOfRange(44,wav.size); val frames=pcm.size/(bpS*ch)
        val mono=FloatArray(frames)
        for(i in 0 until frames){ var sum=0.0
            for(c in 0 until ch){ val idx=(i*ch+c)*bpS
                sum+=if(bpS==2) ByteBuffer.wrap(pcm,idx,2).order(ByteOrder.LITTLE_ENDIAN).short.toInt()
                     else pcm.getOrElse(idx){0}.toInt() }; mono[i]=(sum/ch).toFloat()/32768f }
        val outN=(frames*16000.0/sr).toInt(); val out=ByteArray(outN*2)
        val ob=ByteBuffer.wrap(out).order(ByteOrder.LITTLE_ENDIAN)
        for(i in 0 until outN){ val si=((i.toLong()*mono.size)/outN).toInt().coerceIn(0,mono.size-1)
            ob.putShort((mono[si]*32767f).toInt().coerceIn(-32768,32767).toShort()) }
        return out
    }

    private fun speakerLocale(id:String)=when(id.lowercase()){
        "hindi","hi"->Locale("hi","IN"); "spanish","es"->Locale("es","ES")
        "french","fr"->Locale.FRENCH; "german","de"->Locale.GERMAN
        "japanese","ja"->Locale.JAPANESE; "korean","ko"->Locale.KOREAN
        "chinese","zh"->Locale.CHINESE; "telugu","te"->Locale("te","IN")
        "bengali","bn"->Locale("bn","IN"); "tamil","ta"->Locale("ta","IN")
        "arabic","ar"->Locale("ar","SA"); "portuguese","pt"->Locale("pt","BR")
        "russian","ru"->Locale("ru","RU"); "italian","it"->Locale.ITALIAN
        else->Locale.US }

    fun release(){ tts?.stop(); tts?.shutdown(); tts=null; ready=false }
}
