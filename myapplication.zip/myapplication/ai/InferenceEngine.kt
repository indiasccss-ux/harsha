package com.example.myapplication.ai

import android.content.Context
import android.util.Log
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.gpu.CompatibilityList
import org.tensorflow.lite.gpu.GpuDelegate
import org.tensorflow.lite.nnapi.NnApiDelegate
import java.nio.ByteBuffer

/**
 * InferenceEngine — shared TFLite interpreter.
 * Delegate cascade: NNAPI (NPU/DSP) → GPU → XNNPACK CPU.
 * Logs every run() latency. Throws hard on all delegate failure.
 */
class InferenceEngine(private val context: Context) {
    private val TAG = "InferenceEngine"
    private var interp: Interpreter? = null
    private var gpuDel: GpuDelegate? = null
    private var nnDel: NnApiDelegate? = null
    private var curBuf: ByteBuffer? = null
    private val lock = Any()

    fun isInitialized() = synchronized(lock) { interp != null }

    fun initialize(buf: ByteBuffer) = synchronized(lock) {
        if (curBuf === buf && interp != null) return@synchronized
        release(); curBuf = buf
        val safe = context.getSharedPreferences("app_prefs", Context.MODE_PRIVATE)
            .getBoolean("safe_mode_enabled", false)
        if (!safe) {
            runCatching {
                val nd = NnApiDelegate()
                Interpreter(buf, Interpreter.Options().apply { addDelegate(nd) }).also {
                    it.allocateTensors(); nnDel = nd; interp = it; Log.i(TAG, "NNAPI delegate"); return@synchronized }
            }.onFailure { nnDel?.close(); nnDel = null; Log.w(TAG, "NNAPI: ${it.message}") }
            runCatching {
                val gd = GpuDelegate(CompatibilityList().bestOptionsForThisDevice)
                Interpreter(buf, Interpreter.Options().apply { addDelegate(gd) }).also {
                    it.allocateTensors(); gpuDel = gd; interp = it; Log.i(TAG, "GPU delegate"); return@synchronized }
            }.onFailure { gpuDel?.close(); gpuDel = null; Log.w(TAG, "GPU: ${it.message}") }
        }
        val th = if (safe) 1 else Runtime.getRuntime().availableProcessors().coerceAtMost(4)
        runCatching {
            Interpreter(buf, Interpreter.Options().apply { setUseXNNPACK(true); setNumThreads(th) }).also {
                it.allocateTensors(); interp = it; Log.i(TAG, "XNNPACK CPU ($th threads)") }
        }.onFailure { release(); throw RuntimeException("All TFLite delegates failed: ${it.message}", it) }
    }

    fun run(inputs: Array<Any>, outputs: MutableMap<Int, Any>) = synchronized(lock) {
        val i = interp ?: throw IllegalStateException("InferenceEngine not initialized")
        outputs.forEach { (_, v) -> (v as? ByteBuffer)?.rewind() }
        val t0 = System.currentTimeMillis()
        i.runForMultipleInputsOutputs(inputs, outputs)
        Log.v(TAG, "run() ${System.currentTimeMillis()-t0}ms")
        outputs.forEach { (_, v) -> (v as? ByteBuffer)?.rewind() }
    }

    fun release() = synchronized(lock) {
        interp?.close(); interp = null; gpuDel?.close(); gpuDel = null
        nnDel?.close(); nnDel = null; curBuf = null
    }
}
