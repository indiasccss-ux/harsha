package com.example.myapplication.ai

import android.content.Context
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.IOException
import java.nio.ByteBuffer
import java.nio.ByteOrder

import com.example.myapplication.core.DubbingSegment

/**
 * WhisperSTT — real on-device STT via TFLite whisper-tiny.
 * REAL: mel-spectrogram → interpreter.run() → BPE decode → text
 * REQUIRES: assets/whisper-tiny.tflite + assets/whisper_vocab.json
 */
class WhisperSTT(
    private val context: Context,
    private val inferenceEngine: InferenceEngine,
    private val modelSwapper: ModelSwapper
) {
    private val TAG = "WhisperSTT"
    private var isInitialized = false
    private val EOT = 50256; private val SOT = 50258
    private val N_MELS = 80; private val N_FRAMES = 3000
    private val SAMPLE_RATE = 16000
    private val MEL_SIZE = N_MELS * N_FRAMES

    private val vocab: Map<Int, String> by lazy { loadVocab() }

    fun warmup() {
        if (isInitialized) return
        kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.Main).launch {
            runCatching { initialize() }.onFailure { Log.e(TAG, "Warmup: ${it.message}") }
        }
    }

    suspend fun initialize(useTinyModel: Boolean = true) = withContext(Dispatchers.IO) {
        if (isInitialized) return@withContext
        val modelName = if (useTinyModel) "whisper-tiny.tflite" else "whisper-base.tflite"
        if (context.assets.list("")?.contains(modelName) != true)
            throw IOException("FATAL: '$modelName' missing from assets/. See README_MODELS.txt")
        modelSwapper.swapTo(ModelSwapper.ModelState.STT, modelName)
        inferenceEngine.initialize(modelSwapper.getCurrentBuffer()
            ?: throw IOException("Null model buffer for $modelName"))
        isInitialized = true
        Log.i(TAG, "WhisperSTT ready ($modelName)")
    }

    suspend fun transcribe(audioData: ByteArray): Result<List<DubbingSegment>> =
        withContext(Dispatchers.Default) {
        if (audioData.isEmpty()) return@withContext Result.success(emptyList())
        if (!isInitialized) return@withContext Result.failure(IllegalStateException("Not initialized"))
        runCatching {
            val t0 = System.currentTimeMillis()
            val n = audioData.size / 2
            val f = FloatArray(n)
            ByteBuffer.wrap(audioData).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
                .also { for (i in 0 until n) f[i] = it.get() / 32768f }
            val raw = MelSpectrogram.compute(f)
            val mel = FloatArray(MEL_SIZE) { i -> if (i < raw.size) raw[i] else -11.5f }
            val inBuf = ByteBuffer.allocateDirect(MEL_SIZE * 4).order(ByteOrder.nativeOrder())
            inBuf.asFloatBuffer().put(mel); inBuf.rewind()
            val outBuf = ByteBuffer.allocateDirect(448 * 4).order(ByteOrder.nativeOrder())
            val ti = System.currentTimeMillis()
            inferenceEngine.run(arrayOf(inBuf), mutableMapOf(0 to outBuf))
            outBuf.rewind()
            val tb = outBuf.asIntBuffer(); val sb = StringBuilder(); var cnt = 0
            while (tb.hasRemaining()) {
                val tok = tb.get()
                if (tok == EOT || tok == 0) break
                if (tok == SOT || tok < 0 || tok > 51865) continue
                sb.append(vocab[tok] ?: ""); cnt++
            }
            val txt = sb.toString().trim()
            Log.i(TAG, "Whisper infer=${System.currentTimeMillis()-ti}ms total=${System.currentTimeMillis()-t0}ms tok=$cnt → \"${txt.take(80)}\"")
            listOf(DubbingSegment(0f, n.toFloat() / SAMPLE_RATE, txt))
        }
    }

    private fun loadVocab(): Map<Int, String> = try {
        val o = JSONObject(context.assets.open("whisper_vocab.json").bufferedReader().readText())
        HashMap<Int, String>(o.length()).also { m ->
            o.keys().forEach { k -> k.toIntOrNull()?.let { id -> m[id] = o.getString(k) } }
        }.also { Log.i(TAG, "Vocab: ${it.size} tokens") }
    } catch (e: Exception) { Log.e(TAG, "Vocab load: ${e.message}"); emptyMap() }

    fun release() { isInitialized = false }
}
