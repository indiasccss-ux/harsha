package com.example.myapplication.ai

import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.nio.ByteBuffer
import com.example.myapplication.core.PowerEfficiencyManager

/**
 * Real-ESRGAN-Ternary: 4K Texture Restoration & Upscaling.
 * Employs 1.58-bit ternary weights for ultra-low latency on NPU.
 * Restores temporal stability and skin details post-lipsync.
 */
class RealESRANTernary(
    private val context: android.content.Context,
    private val inferenceEngine: InferenceEngine,
    private val modelSwapper: ModelSwapper,
    private val performanceManager: PowerEfficiencyManager
) {

    private val MODEL_ASSET = "real-esrgan-4k.tflite"

    private var isInitialized = false

    // REUSABLE BUFFERS: Prevent OOM by avoiding per-frame allocations
    private var persistentOutputBuffer: ByteBuffer? = null
    private var inputMap: Array<Any>? = null
    private val outputMap = mutableMapOf<Int, Any>()

    /**
     * Non-blocking warmup for background preloading.
     */
    fun warmup() {
        if (isInitialized) return
        kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launch {
            try {
                // Check asset existence
                val assetList = context.assets.list("") // context needs to be available? Valid point.
                // context is not passed to warmup directly, but it is available in init?
                // Wait, RealESRANTernary doesn't have 'context' in its constructor in the previous view! 
                // Let me check the file content again in my memory or view it if needed.
                // It has inferenceEngine etc.
                // Ah, checking the previous view of RealESRANTernary.
                
                modelSwapper.swapTo(ModelSwapper.ModelState.UPSCALING, MODEL_ASSET)
                val buffer = modelSwapper.getCurrentBuffer()
                if (buffer != null) {
                    inferenceEngine.initialize(buffer)
                    isInitialized = true
                    Log.d("RealESRGAN", "Warmup successful: Model ready.")
                }
            } catch (e: Exception) {
                Log.e("RealESRGAN", "Warmup failed")
            }
        }
    }

    fun isModelAvailable(): Boolean = isInitialized

    suspend fun upscale(latentFrame: ByteBuffer, frameIndex: Int): ByteBuffer {
        if (!isInitialized) {
            Log.e("RealESRGAN", "❌ PREMATURE UPSCALE: Upscaler not initialized.")
            throw IllegalStateException("RealESRANTernary accessed before READY state.")
        }
        val mode = performanceManager.getRecommendedMode()
        
        // 0. Device-Aware Guard: Skip upscaling in low-power or throttled modes
        if (mode == PowerEfficiencyManager.PowerMode.ULP || mode == PowerEfficiencyManager.PowerMode.THROTTLED) {
            Log.i("RealESRGAN", "Upscaling skipped for frame $frameIndex due to power mode: $mode")
            return latentFrame
        }

        Log.d("RealESRGAN", "Mode: $mode. Performing 1080p AI upscaling/restoration...")

        try {
            // 1. Swap to Upscale Model
            modelSwapper.swapTo(ModelSwapper.ModelState.UPSCALING, MODEL_ASSET)
            val buffer = modelSwapper.getCurrentBuffer() ?: run {
                Log.e("RealESRGAN", "Upscaling model unavailable. Falling back.")
                return latentFrame
            }

            // 2. Init Engine
            inferenceEngine.initialize(buffer)

            // 3. Run Inference (Enabled)
            latentFrame.rewind()
            val input: Array<Any> = arrayOf(latentFrame)
            
            // Output: [1, 512, 512, 3] in Float32 (4 bytes per float)
            val outCapacity = 512 * 512 * 3 * 4 
            
            // Reuse persistent buffer
            if (persistentOutputBuffer == null || persistentOutputBuffer!!.capacity() < outCapacity) {
                persistentOutputBuffer = java.nio.ByteBuffer.allocateDirect(outCapacity)
                persistentOutputBuffer!!.order(java.nio.ByteOrder.nativeOrder())
            }
            val outputBuffer = persistentOutputBuffer!!
            outputBuffer.clear()
            
            val outputs = mutableMapOf<Int, Any>(0 to outputBuffer)

            inferenceEngine.run(inputs = input, outputs = outputs)
            
            outputBuffer.rewind()
            Log.v("RealESRGAN", "Frame $frameIndex upscaled successfully.")
            return outputBuffer
            
            /*
            Log.d("RealESRGAN", "Stabilization Fallback: Returning original frame.")
            latentFrame.rewind() // Ensure original buffer is rewound if it was consumed
            return latentFrame
            */
        } catch (e: Exception) {
            Log.e("RealESRGAN", "Upscale failed for frame $frameIndex: ${e.message}. Falling back.")
            latentFrame.rewind()
            return latentFrame 
        } finally {
            // Cleanup engine resources if needed
            // inferenceEngine.release()
        }
    }
}
