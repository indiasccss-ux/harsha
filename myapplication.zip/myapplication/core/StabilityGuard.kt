package com.example.myapplication.core

import android.content.Context
import android.util.Log
import java.io.File

/**
 * Stability Guard (Phase-7).
 * Implements self-healing pipelines and crash-loop detection.
 * Ensures the app remains stable across millions of devices without a backend.
 */
class StabilityGuard(private val context: Context) {
    private val TAG = "StabilityGuard"
    private val STABILITY_PREFS = "stability_prefs"
    private val KEY_CRASH_COUNT = "consecutive_crashes"
    private val KEY_LAST_VERSION = "last_run_version"
    private val MAX_CRASH_THRESHOLD = 3

    /**
     * Records a successful operation to reset the crash counter.
     */
    fun recordSuccess() {
        context.getSharedPreferences(STABILITY_PREFS, Context.MODE_PRIVATE)
            .edit()
            .putInt(KEY_CRASH_COUNT, 0)
            .apply()
    }

    /**
     * Checks if a self-healing reset is required due to consecutive crashes.
     */
    fun isResetRequired(): Boolean {
        val prefs = context.getSharedPreferences(STABILITY_PREFS, Context.MODE_PRIVATE)
        return prefs.getInt(KEY_CRASH_COUNT, 0) >= MAX_CRASH_THRESHOLD
    }

    /**
     * Performs a self-healing reset of the AI pipeline components.
     * Clears temporary caches and corrupt model states.
     */
    fun performPipeReset() {
        Log.w(TAG, "Critical stability threshold reached. Performing Self-Healing Pipe Reset...")
        
        // 1. Clear Temp Files
        context.cacheDir.deleteRecursively()
        
        // 2. Clear corrupted voice profiles (minimal)
        val profileDir = File(context.filesDir, "voice_profiles")
        profileDir.walkBottomUp().forEach { file ->
            if (file.extension == "vec" || file.extension == "tmp") file.delete()
        }
        
        // 3. Reset Crash Counter
        recordSuccess()
        Log.i(TAG, "Pipe reset complete. System restored to clean state.")
    }

    /**
     * Increments the crash counter. Should be called at the start of risky operations.
     */
    fun incrementCrashCount() {
        val prefs = context.getSharedPreferences(STABILITY_PREFS, Context.MODE_PRIVATE)
        val count = prefs.getInt(KEY_CRASH_COUNT, 0)
        prefs.edit().putInt(KEY_CRASH_COUNT, count + 1).apply()
        Log.w(TAG, "Crash count incremented: ${count + 1}")
    }

    /**
     * Checks for version mismatches or corrupted model cold-starts.
     */
    fun checkColdStartHealth(currentVersion: Int): Boolean {
        val prefs = context.getSharedPreferences(STABILITY_PREFS, Context.MODE_PRIVATE)
        val lastVersion = prefs.getInt(KEY_LAST_VERSION, -1)
        
        if (lastVersion != currentVersion) {
            Log.i(TAG, "New version detected ($currentVersion). Clearing legacy caches.")
            performPipeReset()
            prefs.edit().putInt(KEY_LAST_VERSION, currentVersion).apply()
        }
        
        return true
    }

    /**
     * Deterministic Rendering Seed.
     * Useful for reproducing bugs in a strictly offline environment.
     */
    fun getDeterministicSeed(): Long {
        return 42L // Standard anchor for reproducible AI behavior
    }
}
