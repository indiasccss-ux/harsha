package com.example.myapplication.core

import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.ResponseBody
import okhttp3.Request
import okhttp3.OkHttpClient
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.sin

// Kotlin snippet: non-blocking call to server /synthesize, parse WAV, convert to ByteArray and call AdvancedAudioMixer
// Place this file in your Android app (adjust package/an import paths as needed). Requires OkHttp dependency.

object SynthesizeClient {
    private val client = OkHttpClient()

    data class SynthesizeParams(val text: String, val lang: String = "en", val speaker: String? = null)

    fun synthesizeAndMix(context: Context, serverUrl: String, params: SynthesizeParams) {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val json = StringBuilder()
                json.append('{')
                json.append("\"text\":\"")
                json.append(params.text.replace("\"", "\\\""))
                json.append('\"')
                json.append(',')
                json.append("\"lang\":\"")
                json.append(params.lang)
                json.append('\"')
                if (params.speaker != null) {
                    json.append(',')
                    json.append("\"speaker\":\"")
                    json.append(params.speaker.replace("\"", "\\\""))
                    json.append('\"')
                }
                json.append('}')

                val body = json.toString().toRequestBody("application/json; charset=utf-8".toMediaTypeOrNull())
                val req = Request.Builder().url(serverUrl.trimEnd('/') + "/synthesize").post(body).build()

                // Attempt network request; if it fails we'll fall back to a local test tone
                var bytes: ByteArray? = null
                try {
                    client.newCall(req).execute().use { resp ->
                        if (!resp.isSuccessful) throw IOException("Unexpected code " + resp)
                        bytes = resp.body?.bytes() ?: throw IOException("Empty body")
                    }
                } catch (e: Exception) {
                    // network failure - log and use offline fallback tone
                    e.printStackTrace()
                    bytes = generateToneWavBytes(durationSec = 1.2, sampleRate = 16000)
                }

                // Parse WAV and extract raw PCM16 bytes compatible with AdvancedAudioMixer
                val wav = parseWav(bytes!!)

                // Use raw PCM16 bytes (little-endian) directly to create AudioTrack
                val pcmBytes = wav.data

                // Create a track and mix. AdvancedAudioMixer.AudioTrack expects ByteArray pcm
                val track = AdvancedAudioMixer.AudioTrack(pcm = pcmBytes, volume = 1.0f, isDialogue = true)

                // Call mixer (this may be CPU-bound; run off main thread as shown)
                val mixed = AdvancedAudioMixer.mix(listOf(track))

                // Optionally write mixed result to a WAV file on storage for debugging or playback
                val outFile = File(context.cacheDir, "synth_mixed.wav")
                writeWav(outFile, mixed, wav.sampleRate)

                // Play mixed audio
                AudioPlayer.playPcm(mixed, wav.sampleRate)

            } catch (e: Exception) {
                e.printStackTrace()
                // handle errors (post to UI thread if necessary)
            }
        }
    }

    // Simple WAV holder
    data class WavData(val data: ByteArray, val sampleRate: Int)

    private fun parseWav(bytes: ByteArray): WavData {
        val buf = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
        val riff = ByteArray(4)
        buf.get(riff)
        if (!String(riff).equals("RIFF")) throw IOException("Not RIFF")
        buf.int // file size
        val wave = ByteArray(4)
        buf.get(wave)
        if (!String(wave).equals("WAVE")) throw IOException("Not WAVE")

        var sampleRate = 16000
        var numChannels = 1
        var dataOffset = -1
        var dataSize = 0

        // iterate chunks
        while (buf.remaining() >= 8) {
            val chunkIdBytes = ByteArray(4)
            buf.get(chunkIdBytes)
            val chunkId = String(chunkIdBytes)
            val chunkSize = buf.int
            if (chunkId == "fmt ") {
                // skip audioFormat
                buf.short
                numChannels = buf.short.toInt() and 0xffff
                sampleRate = buf.int
                buf.int // byte rate
                buf.short // block align
                buf.short // bits per sample
                // skip any extra fmt bytes
                val remainingInFmt = chunkSize - 16
                if (remainingInFmt > 0) buf.position(buf.position() + remainingInFmt)
            } else if (chunkId == "data") {
                dataOffset = buf.position()
                dataSize = chunkSize
                break
            } else {
                // skip chunk
                buf.position((buf.position() + chunkSize).coerceAtMost(buf.limit()))
            }
        }

        if (dataOffset < 0) throw IOException("No data chunk in WAV")

        // Extract raw PCM16 data bytes
        val dataBytes = ByteArray(dataSize)
        System.arraycopy(bytes, dataOffset, dataBytes, 0, dataSize)

        // If multi-channel, downmix to mono by taking first channel
        if (numChannels > 1) {
            val mono = ByteArray((dataSize / numChannels))
            var i = 0
            var out = 0
            while (i + (numChannels * 2) <= dataBytes.size) {
                mono[out] = dataBytes[i]
                mono[out + 1] = dataBytes[i + 1]
                i += numChannels * 2
                out += 2
            }
            return WavData(mono, sampleRate)
        }

        return WavData(dataBytes, sampleRate)
    }

    private fun writeWav(file: File, pcm16Bytes: ByteArray, sampleRate: Int) {
        FileOutputStream(file).use { fos ->
            val byteRate = sampleRate * 2 // mono, 16-bit

            // RIFF header
            fos.write("RIFF".toByteArray())
            fos.write(intToByteArray(36 + pcm16Bytes.size))
            fos.write("WAVE".toByteArray())

            // fmt chunk
            fos.write("fmt ".toByteArray())
            fos.write(intToByteArray(16)) // fmt chunk size
            fos.write(shortToByteArray(1)) // audio format 1=PCM
            fos.write(shortToByteArray(1)) // channels
            fos.write(intToByteArray(sampleRate))
            fos.write(intToByteArray(byteRate))
            fos.write(shortToByteArray(2)) // block align
            fos.write(shortToByteArray(16)) // bits per sample

            // data chunk
            fos.write("data".toByteArray())
            fos.write(intToByteArray(pcm16Bytes.size))
            fos.write(pcm16Bytes)
            fos.flush()
        }
    }

    private fun intToByteArray(i: Int): ByteArray {
        val b = ByteArray(4)
        b[0] = (i and 0xFF).toByte()
        b[1] = ((i shr 8) and 0xFF).toByte()
        b[2] = ((i shr 16) and 0xFF).toByte()
        b[3] = ((i shr 24) and 0xFF).toByte()
        return b
    }

    private fun shortToByteArray(s: Int): ByteArray {
        val b = ByteArray(2)
        b[0] = (s and 0xFF).toByte()
        b[1] = ((s shr 8) and 0xFF).toByte()
        return b
    }

    // Generate a simple mono WAV bytes containing a sine tone for local testing
    private fun generateToneWavBytes(durationSec: Double, sampleRate: Int): ByteArray {
        val samples = (durationSec * sampleRate).toInt().coerceAtLeast(1)
        val pcm = ByteArray(samples * 2)
        val freq = 440.0 // A4 tone
        for (i in 0 until samples) {
            val t = i.toDouble() / sampleRate
            val v = (sin(2.0 * PI * freq * t) * Short.MAX_VALUE * 0.5).toInt().coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt())
            pcm[i * 2] = (v and 0xFF).toByte()
            pcm[i * 2 + 1] = ((v shr 8) and 0xFF).toByte()
        }

        // Build a minimal WAV with header + pcm
        val totalDataLen = pcm.size
        val header = ByteArray(44)
        // RIFF
        header[0] = 'R'.code.toByte(); header[1] = 'I'.code.toByte(); header[2] = 'F'.code.toByte(); header[3] = 'F'.code.toByte()
        val fileSize = 36 + totalDataLen
        val fileSizeBytes = intToByteArray(fileSize)
        System.arraycopy(fileSizeBytes, 0, header, 4, 4)
        header[8] = 'W'.code.toByte(); header[9] = 'A'.code.toByte(); header[10] = 'V'.code.toByte(); header[11] = 'E'.code.toByte()
        // fmt chunk
        header[12] = 'f'.code.toByte(); header[13] = 'm'.code.toByte(); header[14] = 't'.code.toByte(); header[15] = ' '.code.toByte()
        System.arraycopy(intToByteArray(16), 0, header, 16, 4)
        System.arraycopy(shortToByteArray(1), 0, header, 20, 2) // PCM
        System.arraycopy(shortToByteArray(1), 0, header, 22, 2) // mono
        System.arraycopy(intToByteArray(sampleRate), 0, header, 24, 4)
        System.arraycopy(intToByteArray(sampleRate * 2), 0, header, 28, 4) // byte rate
        System.arraycopy(shortToByteArray(2), 0, header, 32, 2) // block align
        System.arraycopy(shortToByteArray(16), 0, header, 34, 2) // bits per sample
        // data chunk
        header[36] = 'd'.code.toByte(); header[37] = 'a'.code.toByte(); header[38] = 't'.code.toByte(); header[39] = 'a'.code.toByte()
        System.arraycopy(intToByteArray(totalDataLen), 0, header, 40, 4)

        val out = ByteArray(header.size + pcm.size)
        System.arraycopy(header, 0, out, 0, header.size)
        System.arraycopy(pcm, 0, out, header.size, pcm.size)
        return out
    }
}
