package com.example.myapplication.core

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Rect
import android.util.Log

/**
 * Handles facial landmark detection and mouth ROI (Region of Interest) extraction.
 * Optimized for LatentSync-Micro (96x96 pixels).
 */
class MouthCropManager {

    private val TAG = "MouthCropManager"
    private val CROP_SIZE = 96

    data class MouthContext(
        val croppedMouth: Bitmap,
        val transformMatrix: Matrix,
        val originalRect: Rect
    )

    private var lastMouthRect: Rect? = null
    private val SMOOTHING_FACTOR = 0.3f // Lower = smoother but more lag

    /**
     * Extracts the mouth region from a video frame.
     */
    fun extractMouth(frame: Bitmap, faceBounds: Rect?): MouthContext? {
        // 2. Resolve Mouth Rect from Context (Simulated if null)
        val rawMouthRect = faceBounds?.let { face ->
            Rect(
                face.left + (face.width() * 0.2).toInt(),
                face.top + (face.height() * 0.55).toInt(),
                face.right - (face.width() * 0.2).toInt(),
                face.bottom - (face.height() * 0.05).toInt()
            )
        } ?: Rect(frame.width/4, frame.height/2, frame.width*3/4, frame.height)

        // 3. Temporal Smoothing (EMA)
        val smoothedMouth = smoothRect(rawMouthRect, lastMouthRect)
        lastMouthRect = smoothedMouth

        // 4. Normalize to 96x96
        val mouthBitmap = Bitmap.createBitmap(CROP_SIZE, CROP_SIZE, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(mouthBitmap)
        val matrix = Matrix()
        val scale = CROP_SIZE.toFloat() / smoothedMouth.width().toFloat()
        matrix.postTranslate(-smoothedMouth.left.toFloat(), -smoothedMouth.top.toFloat())
        matrix.postScale(scale, scale)
        
        canvas.drawBitmap(frame, matrix, null)

        return MouthContext(mouthBitmap, matrix, smoothedMouth)
    }

    private fun smoothRect(current: Rect, previous: Rect?): Rect {
        if (previous == null) return current
        
        fun lerp(a: Int, b: Int) = (a * (1.0f - SMOOTHING_FACTOR) + b * SMOOTHING_FACTOR).toInt()
        
        return Rect(
            lerp(previous.left, current.left),
            lerp(previous.top, current.top),
            lerp(previous.right, current.right),
            lerp(previous.bottom, current.bottom)
        )
    }

    /**
     * Blends the synced mouth back into the original frame with alpha feathering (ideal).
     */
    fun blendMouth(originalFrame: Bitmap, syncedMouth: Bitmap, context: MouthContext): Bitmap {
        val result = originalFrame.copy(originalFrame.config ?: Bitmap.Config.ARGB_8888, true)
        val canvas = Canvas(result)
        
        val invMatrix = Matrix()
        context.transformMatrix.invert(invMatrix)
        
        // Simple blend for Phase-3. Production uses Gradient Blending.
        canvas.drawBitmap(syncedMouth, invMatrix, null)
        return result
    }
}
