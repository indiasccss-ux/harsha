package com.example.myapplication.core

import android.util.Log
import kotlin.math.max
import kotlin.math.min

/**
 * Governs emotion state across segments to ensure smooth transitions and prevent over-acting.
 */
class EmotionGovernor {
    private val TAG = "EmotionGovernor"
    
    private var lastEmotion: Emotion = Emotion.NEUTRAL
    private var consecutiveCount = 0
    private var lastIntensity = 1.0f

    data class ResolvedEmotion(
        val emotion: Emotion,
        val intensity: Float
    )

    /**
     * Resolves the effective emotion and intensity for a DubbingSegment.
     */
    fun resolve(requested: Emotion, baseIntensity: Float = 1.0f, silenceSinceLast: Float = 0f): ResolvedEmotion {
        // 1. Reset on long silence
        if (silenceSinceLast > 2.0f) {
            lastEmotion = Emotion.NEUTRAL
            consecutiveCount = 0
            Log.d(TAG, "Silence detected ($silenceSinceLast s). Resetting emotion state.")
        }

        // 2. Fatigue Prevention (Damping)
        if (requested == lastEmotion && requested != Emotion.NEUTRAL) {
            consecutiveCount++
        } else {
            consecutiveCount = 0
        }

        var effectiveIntensity = baseIntensity
        if (consecutiveCount >= 3) {
            // Gradually damp intensity if over-acting same emotion
            val dampingFactor = max(0.4f, 1.0f - (consecutiveCount - 2) * 0.15f)
            effectiveIntensity *= dampingFactor
            Log.i(TAG, "Applying emotion damping: $requested (Consecutive: $consecutiveCount, Factor: $dampingFactor)")
        }

        // 3. Transition Smoothing (Simple LERP proxy)
        // If switching from high-energy (HAPPY/ANGRY) to low-energy (SAD/WHISPER),
        // we might want a neutral buffer, but for now we just log the jump.
        if (isHighEnergy(lastEmotion) && isLowEnergy(requested)) {
            Log.w(TAG, "Abrupt emotion jump: $lastEmotion -> $requested. Smoothing may be required.")
            effectiveIntensity *= 0.8f // Subtler start for abrupt transitions
        }

        lastEmotion = requested
        lastIntensity = effectiveIntensity

        return ResolvedEmotion(requested, effectiveIntensity)
    }

    private fun isHighEnergy(e: Emotion) = e == Emotion.HAPPY || e == Emotion.ANGRY
    private fun isLowEnergy(e: Emotion) = e == Emotion.SAD || e == Emotion.WHISPER

    fun reset() {
        lastEmotion = Emotion.NEUTRAL
        consecutiveCount = 0
        lastIntensity = 1.0f
    }
}
