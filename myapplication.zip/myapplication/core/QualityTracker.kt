package com.example.myapplication.core

import android.util.Log

/**
 * Tracks quality metrics for cloned audio segments to detect drift and instability.
 */
class QualityTracker {
    private val TAG = "QualityTracker"
    private val scores = mutableListOf<Int>()
    private val WINDOW_SIZE = 5

    data class QualityStatus(
        val movingAverage: Float,
        val isDecaying: Boolean,
        val needsReanchor: Boolean
    )

    fun logSegment(score: Int) {
        scores.add(score)
        if (scores.size > 50) scores.removeAt(0)
        Log.d(TAG, "DubbingSegment Score: $score | Moving Avg: ${getMovingAverage()}")
    }

    fun getStatus(): QualityStatus {
        val avg = getMovingAverage()
        val isDecaying = checkDecay()
        return QualityStatus(
            movingAverage = avg,
            isDecaying = isDecaying,
            needsReanchor = avg < 50f || isDecaying
        )
    }

    private fun getMovingAverage(): Float {
        if (scores.isEmpty()) return 100f
        val window = scores.takeLast(WINDOW_SIZE)
        return window.sum().toFloat() / window.size
    }

    private fun checkDecay(): Boolean {
        if (scores.size < WINDOW_SIZE * 2) return false
        val recentAvg = scores.takeLast(WINDOW_SIZE).sum().toFloat() / WINDOW_SIZE
        val previousAvg = scores.dropLast(WINDOW_SIZE).takeLast(WINDOW_SIZE).sum().toFloat() / WINDOW_SIZE
        
        // Significant drop (>15 points) suggests drift or instability
        return (previousAvg - recentAvg) > 15f
    }

    fun reset() {
        scores.clear()
        Log.i(TAG, "Quality metrics reset for new video or re-anchor.")
    }
}
