package com.example.myapplication.core

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import android.util.Log
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer

/**
 * Container for extracted PCM audio with format metadata.
 * Optimized: Uses File instead of ByteArray to prevent OOM.
 */
data class AudioBuffer(
    val file: File?,
    val sampleRate: Int,
    val channels: Int
)

/**
 * Extracts raw PCM audio from local video files for AI processing.
 * Decodes to 16kHz Mono 16-bit PCM for AI models (Moonshine/STT).
 */
class LocalAudioExtractor(private val context: Context) {

    fun extractAudio(videoFile: File): AudioBuffer {
        Log.i("LocalAudioExtractor", "Extracting from File: ${videoFile.absolutePath}")
        
        val extractor = MediaExtractor()

        try {
            if (!videoFile.exists() || !videoFile.canRead()) {
                Log.e("LocalAudioExtractor", "CRITICAL: File does not exist or is not readable: ${videoFile.absolutePath}")
                return AudioBuffer(null, 16000, 1)
            }
            extractor.setDataSource(videoFile.absolutePath)
            Log.d("LocalAudioExtractor", "DataSource set successfully from Direct Path")
        } catch (e: Exception) {
            Log.e("LocalAudioExtractor", "CRITICAL: Fatal error during setDataSource: ${e.message}", e)
            return AudioBuffer(null, 16000, 1)
        }

        val trackCount = extractor.trackCount
        Log.d("LocalAudioExtractor", "Track count discovered: $trackCount")
        
        // 1. Find Audio Track
        var audioTrackIndex = -1
        for (i in 0 until trackCount) {
            val format = try { extractor.getTrackFormat(i) } catch (e: Exception) { null } ?: continue
            val mime = format.getString(MediaFormat.KEY_MIME) ?: "unknown"
            Log.v("LocalAudioExtractor", "Track $i: MIME=$mime")
            if (mime.startsWith("audio/")) {
                audioTrackIndex = i
                break
            }
        }

        if (audioTrackIndex == -1) {
            Log.e("LocalAudioExtractor", "CRITICAL: No audio track found in $trackCount total tracks.")
            Log.e("LocalAudioExtractor", "HINT: Is the file corrupted or a non-media file?")
            return AudioBuffer(null, 16000, 1)
        }

        extractor.selectTrack(audioTrackIndex)
        val inputFormat = extractor.getTrackFormat(audioTrackIndex)
        val mime = inputFormat.getString(MediaFormat.KEY_MIME) ?: "unknown"
        
        val srcSampleRate = if (inputFormat.containsKey(MediaFormat.KEY_SAMPLE_RATE)) inputFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE) else 0
        val srcChannels = if (inputFormat.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) inputFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT) else 0
        
        if (srcSampleRate <= 0) {
            Log.e("LocalAudioExtractor", "CRITICAL: Invalid sample rate ($srcSampleRate) found in track metadata.")
            return AudioBuffer(null, 16000, 1)
        }
        
        Log.d("LocalAudioExtractor", "Audio Track Selected: $mime, Source: ${srcSampleRate}Hz ${srcChannels}ch")

        val decoder = try {
            MediaCodec.createDecoderByType(mime)
        } catch (e: Exception) {
            Log.e("LocalAudioExtractor", "CRITICAL: Failed to create decoder for $mime: ${e.message}")
            return AudioBuffer(null, 16000, 1)
        }
        
        try {
            decoder.configure(inputFormat, null, null, 0)
            decoder.start()
        } catch (e: Exception) {
            Log.e("LocalAudioExtractor", "CRITICAL: Failed to configure/start decoder: ${e.message}")
            decoder.release()
            return AudioBuffer(null, 16000, 1)
        }

        val tempFile = File(context.cacheDir, "temp_audio_extract_${System.currentTimeMillis()}.pcm")
        val outputStream = FileOutputStream(tempFile)
        val info = MediaCodec.BufferInfo()
        var isEOS = false
        var totalDecodedBytes = 0
        var totalExtractedBytes = 0
        var loopCount = 0

        try {
            while (!isEOS) {
                loopCount++
                val inputIndex = decoder.dequeueInputBuffer(10000)
                if (inputIndex >= 0) {
                    val inputBuffer = decoder.getInputBuffer(inputIndex)!!
                    val sampleSize = extractor.readSampleData(inputBuffer, 0)
                    if (sampleSize < 0) {
                        decoder.queueInputBuffer(inputIndex, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                        isEOS = true
                    } else {
                        decoder.queueInputBuffer(inputIndex, 0, sampleSize, extractor.sampleTime, 0)
                        extractor.advance()
                        totalExtractedBytes += sampleSize
                    }
                }

                var outputIndex = decoder.dequeueOutputBuffer(info, 10000)
                while (outputIndex >= 0) {
                    val outputBuffer = decoder.getOutputBuffer(outputIndex)!!
                    val chunk = ByteArray(info.size)
                    outputBuffer.get(chunk)
                    outputStream.write(chunk)
                    totalDecodedBytes += info.size
                    decoder.releaseOutputBuffer(outputIndex, false)
                    outputIndex = decoder.dequeueOutputBuffer(info, 0)
                }
                
                if (loopCount % 500 == 0) {
                    Log.v("LocalAudioExtractor", "Processing... Extracted: $totalExtractedBytes bytes, Decoded: $totalDecodedBytes bytes")
                }
            }
            Log.d("LocalAudioExtractor", "Extraction finished. Total Extracted: $totalExtractedBytes, Total Decoded: $totalDecodedBytes bytes")
        } catch (e: Exception) {
            Log.e("LocalAudioExtractor", "CRITICAL: Codec Loop Failed: ${e.message}")
            return AudioBuffer(null, 16000, 1)
        } finally {
            try {
                decoder.stop()
                decoder.release()
                extractor.release()
                outputStream.close()
            } catch (e: Exception) {
                Log.w("LocalAudioExtractor", "Cleanup warning: ${e.message}")
            }
        }

        if (tempFile.length() > 200 * 1024 * 1024) { // Increased to 200MB since it's on disk now
             Log.e("LocalAudioExtractor", "Audio too large (${tempFile.length()} bytes). Storage limit exceeded.")
             tempFile.delete()
             return AudioBuffer(null, 16000, 1) 
        }

        // 3. Resample to 16kHz Mono for AI Models if needed
        return if (srcSampleRate == 16000 && srcChannels == 1) {
            Log.d("LocalAudioExtractor", "Extraction finished. Data is already 16k mono.")
            AudioBuffer(tempFile, 16000, 1)
        } else {
            Log.d("LocalAudioExtractor", "Resampling from ${srcSampleRate}Hz ${srcChannels}ch to 16kHz Mono...")
            val resampledFile = File(context.cacheDir, "resampled_${System.currentTimeMillis()}.pcm")
            resampledFile.outputStream().use { os ->
                 val pcmData = tempFile.readBytes() // Still reading here for simplicity, but in a production app we'd stream this too.
                 // For now, let's keep it simple but mark it.
                 val resampled = resamplePcm(pcmData, srcSampleRate, srcChannels, 16000, 1)
                 os.write(resampled)
            }
            tempFile.delete()
            Log.d("LocalAudioExtractor", "Resampling complete. Final file: ${resampledFile.absolutePath}")
            AudioBuffer(resampledFile, 16000, 1)
        }
    }

    fun getDurationMs(videoFile: File): Long {
        val extractor = MediaExtractor()
        return try {
            extractor.setDataSource(videoFile.absolutePath)
            val trackCount = extractor.trackCount
            for (i in 0 until trackCount) {
                val format = extractor.getTrackFormat(i)
                if (format.getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true) {
                    return if (format.containsKey(MediaFormat.KEY_DURATION)) format.getLong(MediaFormat.KEY_DURATION) / 1000 else 0L
                }
            }
            0L
        } catch (e: Exception) { 0L } finally { extractor.release() }
    }

    /**
     * Extracts a specific chunk of audio from a video file.
     * Decodes and resamples to 16kHz Mono PCM.
     */
    fun extractAudioChunk(videoFile: File, startMs: Long, durationMs: Long): ByteArray {
        val extractor = MediaExtractor()
        try {
            extractor.setDataSource(videoFile.absolutePath)
            var audioTrackIndex = -1
            for (i in 0 until extractor.trackCount) {
                val format = extractor.getTrackFormat(i)
                if (format.getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true) {
                    audioTrackIndex = i
                    break
                }
            }
            if (audioTrackIndex == -1) return ByteArray(0)
            
            extractor.selectTrack(audioTrackIndex)
            val format = extractor.getTrackFormat(audioTrackIndex)
            val mime = format.getString(MediaFormat.KEY_MIME) ?: return ByteArray(0)
            val srcRate = format.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            val srcChannels = format.getInteger(MediaFormat.KEY_CHANNEL_COUNT)

            val decoder = MediaCodec.createDecoderByType(mime)
            decoder.configure(format, null, null, 0)
            decoder.start()

            extractor.seekTo(startMs * 1000, MediaExtractor.SEEK_TO_CLOSEST_SYNC)
            
            val info = MediaCodec.BufferInfo()
            val chunkStream = java.io.ByteArrayOutputStream()
            var isEOS = false
            val endUs = (startMs + durationMs) * 1000
            
            while (!isEOS && extractor.sampleTime < endUs) {
                val inIdx = decoder.dequeueInputBuffer(5000)
                if (inIdx >= 0) {
                    val buf = decoder.getInputBuffer(inIdx)!!
                    val size = extractor.readSampleData(buf, 0)
                    if (size < 0) {
                        decoder.queueInputBuffer(inIdx, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                        isEOS = true
                    } else {
                        decoder.queueInputBuffer(inIdx, 0, size, extractor.sampleTime, 0)
                        extractor.advance()
                    }
                }

                var outIdx = decoder.dequeueOutputBuffer(info, 5000)
                while (outIdx >= 0) {
                    val outBuf = decoder.getOutputBuffer(outIdx)!!
                    val data = ByteArray(info.size)
                    outBuf.get(data)
                    chunkStream.write(data)
                    decoder.releaseOutputBuffer(outIdx, false)
                    outIdx = decoder.dequeueOutputBuffer(info, 0)
                }
            }

            decoder.stop()
            decoder.release()
            
            val rawPcm = chunkStream.toByteArray()
            return if (srcRate == 16000 && srcChannels == 1) {
                rawPcm
            } else {
                resamplePcm(rawPcm, srcRate, srcChannels, 16000, 1)
            }
        } catch (e: Exception) {
            Log.e("LocalAudioExtractor", "Chunk extraction failed: ${e.message}")
            return ByteArray(0)
        } finally {
            extractor.release()
        }
    }

    private fun resamplePcm(data: ByteArray, srcRate: Int, srcChannels: Int, dstRate: Int, dstChannels: Int): ByteArray {
        if (data.isEmpty()) return ByteArray(0)
        
        val bytesPerSample = 2
        val numInputSamples = data.size / (srcChannels * bytesPerSample)
        val numOutputSamples = (numInputSamples.toLong() * dstRate / srcRate).toInt()
        val outputPcm = ByteArray(numOutputSamples * dstChannels * bytesPerSample)

        for (i in 0 until numOutputSamples) {
            val inputSampleIndex = i.toDouble() * srcRate / dstRate
            val i0 = inputSampleIndex.toInt()
            val i1 = minOf(i0 + 1, numInputSamples - 1)
            val frac = inputSampleIndex - i0

            // Mix channels to mono if needed
            val sample0 = (getSampleNative(data, i0, srcChannels) * (1 - frac)).toInt()
            val sample1 = (getSampleNative(data, i1, srcChannels) * frac).toInt()
            val newSample = sample0 + sample1

            // Write to output (assuming mono target for now as per requirements)
            outputPcm[i * bytesPerSample] = (newSample and 0xFF).toByte()
            outputPcm[i * bytesPerSample + 1] = ((newSample shr 8) and 0xFF).toByte()
        }
        return outputPcm
    }

    private fun getSampleNative(data: ByteArray, index: Int, numChannels: Int): Int {
        val pos = index * numChannels * 2
        if (pos + 1 >= data.size) return 0
        val left = (data[pos].toInt() and 0xFF) or (data[pos + 1].toInt() shl 8)
        val leftVal = if (left > 32767) left - 65536 else left
        
        if (numChannels == 1) return leftVal
        
        if (pos + 3 >= data.size) return leftVal
        val right = (data[pos + 2].toInt() and 0xFF) or (data[pos + 3].toInt() shl 8)
        val rightVal = if (right > 32767) right - 65536 else right
        
        return (leftVal + rightVal) / 2
    }
}
