package com.example.myapplication.core

import android.graphics.Bitmap

/**
 * Supported emotions for TTS.
 */
enum class Emotion {
    NEUTRAL, HAPPY, SAD, ANGRY, WHISPER, FEAR, SURPRISE
}

/**
 * Metadata for a specific speaker voice.
 */
data class VoiceProfile(
    val speakerId: String,
    val name: String,
    val referenceAudioPaths: List<String> = emptyList(),
    val isCloned: Boolean = false,
    val readinessScore: Int = 0, // 0-100
    val pitchShift: Float = 1.0f // Acoustic pitch multiplier (0.7 - 1.4)
) {

    companion object {
        val NEUTRAL = VoiceProfile("neutral", "Neutral Voice")
    }
}

/**
 * Standardized DubbingSegment model for the entire pipeline.
 */
data class DubbingSegment(
    val start: Float,
    val end: Float,
    val text: String,
    val speakerId: String = "neutral",
    val emotion: Emotion = Emotion.NEUTRAL,
    val referenceAudioIds: List<String> = emptyList()
)

interface IVocalEngine {
    suspend fun speak(
        text: String, 
        profile: VoiceProfile = VoiceProfile.NEUTRAL, 
        emotion: Emotion = Emotion.NEUTRAL, 
        intensity: Float = 1.0f
    ): ByteArray
}

/**
 * Result container for the Dubbing Pipeline.
 */
data class DubbingResult(
    val videoPath: String?,
    val audioData: ByteArray,
    val success: Boolean,
    val finalEmotion: Emotion = Emotion.NEUTRAL
)

/**
 * Streaming Chunk for Progressive Playback.
 */
data class DubbingChunk(
    val audioData: ByteArray,
    val progress: Float,
    val isFinal: Boolean,
    val message: String? = null,
    val visualFrame: android.graphics.Bitmap? = null
)
