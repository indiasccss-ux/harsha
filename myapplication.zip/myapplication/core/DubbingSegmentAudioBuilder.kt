package com.example.myapplication.core

import android.content.Context
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

/**
 * Orchestrates per-DubbingSegment audio building.
 */
class DubbingSegmentAudioBuilder(
    private val context: Context,
    private val vocalEngine: IVocalEngine
) {
    private val TAG = "DubbingSegmentAudioBuilder"

    suspend fun build(
        segment: DubbingSegment, 
        profile: VoiceProfile = VoiceProfile.NEUTRAL,
        originalVocalPcm: ByteArray? = null,
        visualIntensity: FloatArray? = null,
        intensity: Float = 1.0f
    ): ByteArray = withContext(Dispatchers.IO) {
        val segmentId = UUID.randomUUID().toString().take(8)
        val text = segment.text
        var effectiveProfile = profile

        if (profile.isCloned) {
            if (profile.readinessScore < 40) {
                Log.w(TAG, "[$segmentId] Voice readiness too low (${profile.readinessScore}). Falling back to NEUTRAL.")
                effectiveProfile = VoiceProfile.NEUTRAL
            }
        }

        try {
            val genAudio = vocalEngine.speak(text, effectiveProfile, segment.emotion, intensity)
            if (genAudio.size <= 44) return@withContext ByteArray(0)
            
            val alignedPcm = if (genAudio.size > 44) genAudio.copyOfRange(44, genAudio.size) else ByteArray(0)
            return@withContext alignedPcm

        } catch (e: Exception) {
            Log.e(TAG, "DubbingSegment building error: ${e.message}")
            return@withContext ByteArray(0)
        }
    }
}
