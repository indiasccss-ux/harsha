package com.example.myapplication.core

import android.util.Log
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Advanced Audio Mixer (Phase-6).
 * Implements professional multi-track mixing, side-chain compression, and mastering.
 * Optimized for on-device performance with 16kHz Mono baseline.
 */
object AdvancedAudioMixer {
    private const val TAG = "AdvancedAudioMixer"
    
    // Side-chain parameters
    private const val ATTACK_MS = 20f
    private const val RELEASE_MS = 200f
    private const val DUCKING_DB = -18f // Aggressive ducking (Voice Over standard) to hide original vocals
    private val DUCKING_RATIO = Math.pow(10.0, DUCKING_DB / 20.0).toFloat()

    data class AudioTrack(
        val pcm: ByteArray,
        val volume: Float = 1.0f,
        val isDialogue: Boolean = false
    )

    /**
     * Professional mix of multiple audio tracks with side-chaining and thermal-aware scaling.
     */
    /**
     * Professional mix of multiple audio tracks with side-chaining and thermal-aware scaling.
     * @param dialogueIntensity Scalar (0.0-1.0) indicating average dialogue energy. Lower intensity = Deeper ducking.
     */
    fun mix(
        tracks: List<AudioTrack>, 
        pMode: PowerEfficiencyManager.PowerMode = PowerEfficiencyManager.PowerMode.BALANCED,
        dialogueIntensity: Float = 1.0f
    ): ByteArray {
        if (tracks.isEmpty()) return ByteArray(0)
        
        val maxLen = tracks.maxOf { it.pcm.size }
        val finalMaxLen = if (maxLen % 2 != 0) maxLen - 1 else maxLen
        val output = ByteArray(finalMaxLen)
        
        // 1. Complexity Scaling
        val stepSize = if (pMode == PowerEfficiencyManager.PowerMode.THROTTLED) 4 else 2
        val useSimplifiedDucking = pMode == PowerEfficiencyManager.PowerMode.ULP

        // Find dialogue track for side-chaining
        val dialogueTrack = tracks.find { it.isDialogue }
        
        // Dynamic Ducking: If dialogue is whispery (low intensity), we need MORE ducking (less BGM)
        // Base DUCKING_DB is -12dB.
        // If intensity is 0.3 (Whisper), we might want -18dB.
        // If intensity is 1.2 (Shout), we can accept -9dB.
        val dynamicDuckingDb = if (dialogueIntensity < 0.5f) DUCKING_DB - 6f else DUCKING_DB
        val duckingRatio = Math.pow(10.0, dynamicDuckingDb / 20.0).toFloat()
        
        // Envelope follower for side-chaining
        var currentDucking = 1.0f
        val attackAlpha = 1.0f - Math.exp(-1.0 / (0.016 * ATTACK_MS)).toFloat()
        val releaseAlpha = 1.0f - Math.exp(-1.0 / (0.016 * RELEASE_MS)).toFloat()

        for (i in 0 until finalMaxLen step stepSize) {
            // Envelope Track (Dialogue)
            var diagSample = 0
            if (!useSimplifiedDucking && dialogueTrack != null && i < dialogueTrack.pcm.size - 1) {
                val low = dialogueTrack.pcm[i].toInt() and 0xFF
                val high = dialogueTrack.pcm[i + 1].toInt()
                diagSample = (high shl 8) or low
                if (diagSample > 32767) diagSample -= 65536
            }

            val vAbs = abs(diagSample) / 32768f
            val targetDucking = if (vAbs > 0.05f) duckingRatio else 1.0f
            
            // Apply Attack/Release
            val alpha = if (targetDucking < currentDucking) attackAlpha else releaseAlpha
            currentDucking = currentDucking * (1.0f - alpha) + targetDucking * alpha

            // 2. Mix Samples
            var mixedSample = 0f
            for (track in tracks) {
                if (i < track.pcm.size - 1) {
                    val low = track.pcm[i].toInt() and 0xFF
                    val high = track.pcm[i + 1].toInt()
                    var s = (high shl 8) or low
                    if (s > 32767) s -= 65536
                    
                    val valF = s / 32768f
                    
                    if (track.isDialogue) {
                        mixedSample += valF * track.volume
                    } else {
                        // All non-dialogue tracks are ducked
                        mixedSample += valF * track.volume * currentDucking
                    }
                }
            }

            // 3. Clipping Guard
            val finalS = (mixedSample.coerceIn(-1f, 1f) * 32767).toInt()
            output[i] = (finalS and 0xFF).toByte()
            output[i + 1] = ((finalS shr 8) and 0xFF).toByte()
        }
        
        return masterAudio(output)
    }

    /**
     * Final Mastering Pass: Normalization & Peak Limiting.
     */
    private fun masterAudio(pcm: ByteArray): ByteArray {
        // Peak normalization to -1.5dB
        var maxPeak = 0f
        val safeSize = if (pcm.size % 2 != 0) pcm.size - 1 else pcm.size
        for (i in 0 until safeSize step 2) {
            val low = pcm[i].toInt() and 0xFF
            val high = pcm[i + 1].toInt()
            var s = (high shl 8) or low
            if (s > 32767) s -= 65536
            val absS = abs(s) / 32768f
            if (absS > maxPeak) maxPeak = absS
        }
        
        if (maxPeak == 0f) return pcm
        
        val targetPeak = 0.84f // ~ -1.5dB
        val gain = targetPeak / maxPeak
        
        if (gain <= 1.0f) return pcm // Already safe

        val output = ByteArray(pcm.size)
        for (i in 0 until safeSize step 2) {
            val low = pcm[i].toInt() and 0xFF
            val high = pcm[i + 1].toInt()
            var s = (high shl 8) or low
            if (s > 32767) s -= 65536
            
            val finalS = ((s * gain).toInt()).coerceIn(-32768, 32767)
            output[i] = (finalS and 0xFF).toByte()
            output[i + 1] = ((finalS shr 8) and 0xFF).toByte()
        }
        
        return output
    }
}
