package com.example.myapplication.core

import android.content.Context
import android.util.Log
import org.json.JSONObject
import java.io.File

/**
 * Crash Recovery Manager (Phase-9).
 * Silent crash recovery and user-friendly fallback states.
 * Enables deterministic bug reproduction for offline debugging.
 */
class CrashRecoveryManager(private val context: Context) {
    private val TAG = "CrashRecoveryManager"
    private val CHECKPOINT_FILE = "pipeline_checkpoint.json"
    
    data class PipelineCheckpoint(
        val videoUri: String,
        val targetLang: String,
        val lastStage: String,
        val timestamp: Long,
        val progressPercent: Float
    )
    
    /**
     * Saves a pipeline checkpoint for crash recovery.
     */
    fun saveCheckpoint(checkpoint: PipelineCheckpoint) {
        try {
            val json = JSONObject().apply {
                put("video_uri", checkpoint.videoUri)
                put("target_lang", checkpoint.targetLang)
                put("last_stage", checkpoint.lastStage)
                put("timestamp", checkpoint.timestamp)
                put("progress", checkpoint.progressPercent)
            }
            
            File(context.cacheDir, CHECKPOINT_FILE).writeText(json.toString())
            Log.d(TAG, "Checkpoint saved: ${checkpoint.lastStage}")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to save checkpoint", e)
        }
    }
    
    /**
     * Loads the last checkpoint if available.
     */
    fun loadCheckpoint(): PipelineCheckpoint? {
        val file = File(context.cacheDir, CHECKPOINT_FILE)
        if (!file.exists()) return null
        
        return try {
            val json = JSONObject(file.readText())
            PipelineCheckpoint(
                videoUri = json.getString("video_uri"),
                targetLang = json.getString("target_lang"),
                lastStage = json.getString("last_stage"),
                timestamp = json.getLong("timestamp"),
                progressPercent = json.getDouble("progress").toFloat()
            )
        } catch (e: Exception) {
            Log.e(TAG, "Failed to load checkpoint", e)
            null
        }
    }
    
    /**
     * Clears checkpoint after successful completion.
     */
    fun clearCheckpoint() {
        File(context.cacheDir, CHECKPOINT_FILE).delete()
    }
    
    /**
     * Checks if there's a recoverable state.
     */
    fun hasRecoverableState(): Boolean {
        val checkpoint = loadCheckpoint() ?: return false
        val age = System.currentTimeMillis() - checkpoint.timestamp
        return age < 3600000 // Within last hour
    }
    
    /**
     * Exports anonymized pipeline state for bug reporting.
     */
    fun exportBugReport(): File? {
        return try {
            val report = JSONObject().apply {
                put("app_version", 100)
                put("device_model", android.os.Build.MODEL)
                put("android_version", android.os.Build.VERSION.SDK_INT)
                put("checkpoint", loadCheckpoint()?.let {
                    JSONObject().apply {
                        put("last_stage", it.lastStage)
                        put("progress", it.progressPercent)
                    }
                })
                
                // Diagnostic logs simplified
                put("health", JSONObject().apply {
                    put("storage_healthy", true)
                    put("android_sdk", android.os.Build.VERSION.SDK_INT)
                })
            }
            
            val reportFile = File(context.cacheDir, "bug_report_${System.currentTimeMillis()}.json")
            reportFile.writeText(report.toString(2))
            Log.i(TAG, "Bug report exported: ${reportFile.absolutePath}")
            reportFile
        } catch (e: Exception) {
            Log.e(TAG, "Failed to export bug report", e)
            null
        }
    }
    
    /**
     * User-friendly error message generator.
     */
    fun getFriendlyErrorMessage(error: Exception): String {
        return when {
            error.message?.contains("OutOfMemory") == true -> 
                "Your device ran out of memory. Try closing other apps and retry."
            error.message?.contains("FileNotFound") == true -> 
                "Video file not found. Please select a different video."
            error.message?.contains("timeout") == true -> 
                "Processing took too long. Try a shorter video."
            else -> 
                "Something went wrong. Tap 'Report' to help us fix this."
        }
    }
    
    /**
     * Determines if error is recoverable.
     */
    /**
     * Determines if error is recoverable.
     */
    fun isRecoverable(error: Exception): Boolean {
        return when {
            error is OutOfMemoryError -> false
            error.message?.contains("corrupted") == true -> false
            else -> true
        }
    }

    fun enableSafeMode() {
        context.getSharedPreferences("app_prefs", Context.MODE_PRIVATE)
            .edit()
            .putBoolean("safe_mode_enabled", true)
            .apply()
        Log.w(TAG, "Safe Mode ENABLED for next run due to crash.")
    }

    /**
     * 🏁 Task 5: Lightweight Checkpoints (SharedPreferences)
     */
    fun saveQuickCheckpoint(stage: String, progress: Float) {
        context.getSharedPreferences("pipeline_recovery", Context.MODE_PRIVATE)
            .edit()
            .putString("stage", stage)
            .putFloat("progress", progress)
            .putLong("timestamp", System.currentTimeMillis())
            .apply()
        Log.d(TAG, "Quick Checkpoint Saved: $stage ($progress%)")
    }

    fun restoreQuickCheckpoint(): Pair<String, Float>? {
        val prefs = context.getSharedPreferences("pipeline_recovery", Context.MODE_PRIVATE)
        val stage = prefs.getString("stage", null) ?: return null
        val progress = prefs.getFloat("progress", 0f)
        val timestamp = prefs.getLong("timestamp", 0)
        
        if (System.currentTimeMillis() - timestamp > 3600000) return null // Old
        return stage to progress
    }
}
