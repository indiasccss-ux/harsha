// ...existing code...
package com.example.myapplication.core

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlin.math.min

object AudioPlayer {
    @Volatile
    private var audioTrack: AudioTrack? = null

    private val scope = CoroutineScope(Dispatchers.IO)
    private var playJob: Job? = null

    // Play raw mono 16-bit little-endian PCM on a background coroutine in streaming mode.
    // Subsequent calls will stop any in-progress playback and start the new one.
    fun playPcm(pcm16: ByteArray, sampleRate: Int) {
        stop() // ensure previous play stopped

        val minBuf = AudioTrack.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        ).coerceAtLeast(2048)

        val audioFormat = AudioFormat.Builder()
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(sampleRate)
            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
            .build()

        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
            .build()

        audioTrack = AudioTrack.Builder()
            .setAudioAttributes(attrs)
            .setAudioFormat(audioFormat)
            .setBufferSizeInBytes(minBuf)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()

        val track = audioTrack
        if (track == null) return

        try {
            track.play()
        } catch (e: Exception) {
            e.printStackTrace()
            track.release()
            audioTrack = null
            return
        }

        playJob = scope.launch {
            try {
                var offset = 0
                while (offset < pcm16.size && track.playState == AudioTrack.PLAYSTATE_PLAYING) {
                    val toWrite = min(minBuf, pcm16.size - offset)
                    var written = 0
                    while (written < toWrite) {
                        val w = track.write(pcm16, offset + written, toWrite - written)
                        if (w <= 0) break
                        written += w
                    }
                    offset += written
                }
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                try {
                    if (track.playState == AudioTrack.PLAYSTATE_PLAYING) track.stop()
                } catch (_: Exception) { }
                try { track.release() } catch (_: Exception) { }
                audioTrack = null
            }
        }
    }

    // Stop current playback and release resources immediately.
    fun stop() {
        playJob?.cancel()
        playJob = null
        val t = audioTrack
        if (t != null) {
            try {
                if (t.playState == AudioTrack.PLAYSTATE_PLAYING) t.stop()
            } catch (_: Exception) { }
            try { t.release() } catch (_: Exception) { }
            audioTrack = null
        }
    }

    // Call to fully cleanup coroutine scope if the process wants to shut down the player
    fun shutdown() {
        stop()
        try { scope.cancel() } catch (_: Exception) { }
    }
}
