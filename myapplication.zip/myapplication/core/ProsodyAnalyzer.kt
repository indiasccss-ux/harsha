package com.example.myapplication.core

import android.util.Log
import kotlin.math.abs
import kotlin.math.sqrt

/**
 * Prosody Analyzer for Audio-Driven Emotion.
 * Extracts F0 (Pitch), Energy (RMS), and Speaking Rate from PCM audio.
 * Maps these acoustic features to emotional states to drive TTS conditioning.
 */
object ProsodyAnalyzer {
    private const val TAG = "ProsodyAnalyzer"

    data class ProsodyFeatures(
        val emotion: Emotion,
        val intensity: Float, // 0.0 to 1.0
        val pitchMeanHz: Float,
        val energyRms: Float
    )

    /**
     * Analyzes a PCM audio DubbingSegment to extract prosody features.
     * @param pcm 16kHz Mono PCM Audio
     * @param text Transcript text (used for heuristic fallback)
     */
    fun analyze(pcm: ByteArray, text: String): ProsodyFeatures {
        if (pcm.isEmpty()) {
            return ProsodyFeatures(Emotion.NEUTRAL, 0.0f, 0f, 0f)
        }

        try {
            // 1. Calculate RMS Energy
            val rms = calculateRms(pcm)
            
            // 2. Estimate Pitch (Simple Zero-Crossing / Autocorrelation proxy for speed)
            // For mobile CPU efficiency, we use Zero-Crossing Rate (ZCR) as a lightweight pitch proxy
            // combined with simple peak distance if needed.
            val zcr = calculateZcr(pcm)
            
            // 3. Map to Emotion & Intensity
            // Heuristic mapping: High Energy + High ZCR -> Happy/Angry
            // Low Energy + Low ZCR -> Sad/Whisper
            
            val energyThreshold = 0.15f // Normalized RMS threshold for "Loud"
            val zcrThreshold = 0.1f     // Normalized ZCR threshold for "High Pitch"

            var emotion = Emotion.NEUTRAL
            var intensity = 0.5f

            if (rms > energyThreshold) {
                // Loud
                if (zcr > zcrThreshold) {
                    // Loud and High Pitch -> Likely Happy or Angry
                    // Discriminate using text heuristics
                    emotion = inferHighEnergyEmotion(text)
                    intensity = ((rms - energyThreshold) / (1.0f - energyThreshold)).coerceIn(0.5f, 1.0f)
                } else {
                    // Loud but Low Pitch -> Likely Serious/Commanding -> Neutral/Angry
                    emotion = Emotion.ANGRY // Assuming forceful
                    intensity = 0.7f
                }
            } else {
                // Quiet
                if (rms < 0.03f) {
                    emotion = Emotion.WHISPER
                    intensity = 1.0f - (rms / 0.03f)
                } else if (zcr < 0.05f) {
                    emotion = Emotion.SAD
                    intensity = 0.6f
                } else {
                    emotion = Emotion.NEUTRAL
                    intensity = 0.4f
                }
            }

            // Refine with text heuristics if neutral
            if (emotion == Emotion.NEUTRAL) {
                 emotion = inferTextHeuristic(text)
            }

            Log.d(TAG, "Analyzed DubbingSegment: RMS=${"%.4f".format(rms)}, ZCR=${"%.4f".format(zcr)} -> $emotion ($intensity)")

            return ProsodyFeatures(
                emotion = emotion,
                intensity = intensity,
                pitchMeanHz = zcr * 8000f, // Rough mapping: ZCR * Nyquist
                energyRms = rms
            )
        } catch (e: Exception) {
            Log.e(TAG, "Analysis failed: ${e.message}. Using Default.", e)
            return ProsodyFeatures(Emotion.NEUTRAL, 0.5f, 100f, 0.1f)
        }
    }

    private fun calculateRms(pcm: ByteArray): Float {
        var sum = 0.0
        var i = 0
        while (i < pcm.size - 1) {
            val low = pcm[i].toInt() and 0xFF
            val high = pcm[i + 1].toInt()
            var sample = (high shl 8) or low
            if (sample > 32767) sample -= 65536
            
            val norm = sample / 32768.0f
            sum += norm * norm
            i += 2
        }
        return sqrt(sum / (pcm.size / 2)).toFloat()
    }

    private fun calculateZcr(pcm: ByteArray): Float {
        var crossings = 0
        var prevSign = 0
        var i = 0
        
        // 16kHz
        while (i < pcm.size - 1) {
            val low = pcm[i].toInt() and 0xFF
            val high = pcm[i + 1].toInt()
            var sample = (high shl 8) or low
            if (sample > 32767) sample -= 65536
            
            val sign = if (sample >= 0) 1 else -1
            if (prevSign != 0 && sign != prevSign) {
                crossings++
            }
            prevSign = sign
            i += 2
        }
        
        return crossings.toFloat() / (pcm.size / 2)
    }

    private fun inferHighEnergyEmotion(text: String): Emotion {
        val lower = text.lowercase()
        return when {
            lower.contains("!") || lower.contains("wow") || lower.contains("great") -> Emotion.HAPPY
            lower.contains("stop") || lower.contains("no") || lower.contains("damn") -> Emotion.ANGRY
            else -> Emotion.HAPPY // Default to energetic happy for high energy
        }
    }
    
    /**
     * Estimates a Pitch Multiplier for TTS based on the input audio's fundamental frequency.
     * Returns:
     * - > 1.0 for High Pitch (Female/Child-like)
     * - < 1.0 for Low Pitch (Male/Deep)
     * - 1.0 for Neutral
     */
    fun getPitchMultiplier(pcm: ByteArray): Float {
        if (pcm.isEmpty()) return 1.0f
        
        // Use ZCR as a lightweight proxy for F0
        val zcr = calculateZcr(pcm)
        
        // Heuristic mapping:
        // Average Human Speech ZCR is roughly 0.05 to 0.15 (depending on content)
        // Neutral Baseline ~ 0.1
        val baselineM = 0.08f
        
        val ratio = zcr / baselineM
        return ratio.coerceIn(0.7f, 1.4f)
    }

    private fun inferTextHeuristic(text: String): Emotion {
         val lower = text.lowercase()
         return when {
            lower.contains("sorry") || lower.contains("sad") -> Emotion.SAD
            lower.contains("?") -> Emotion.NEUTRAL // Question
            else -> Emotion.NEUTRAL
        }
    }
}
