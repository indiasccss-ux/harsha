package com.example.myapplication.core

/**
 * Configuration for emotion-based prosody.
 */
data class EmotionProsody(
    val pitchMultiplier: Float,
    val rateMultiplier: Float,
    val energyOffsetDb: Float
)

object EmotionParameterMap {
    private val map = mapOf(
        Emotion.NEUTRAL to EmotionProsody(1.00f, 1.00f, 0f),
        Emotion.HAPPY to EmotionProsody(1.15f, 1.10f, 1.5f), // Brighter, energetic
        Emotion.SAD to EmotionProsody(0.90f, 0.85f, -2.5f), // Somber, slower
        Emotion.ANGRY to EmotionProsody(1.05f, 1.15f, 2.5f), // Assertive, fast
        Emotion.WHISPER to EmotionProsody(0.95f, 0.90f, -6.0f), // Soft, intimate
        Emotion.FEAR to EmotionProsody(1.20f, 1.25f, 1.0f), // High pitch, frantic
        Emotion.SURPRISE to EmotionProsody(1.25f, 1.10f, 1.0f) // Sharp pitch rise
    )

    fun getProsody(emotion: Emotion): EmotionProsody {
        return map[emotion] ?: map[Emotion.NEUTRAL]!!
    }
}
