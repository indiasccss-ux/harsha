package com.example.myapplication.core

import android.content.Context
import android.net.Uri
import android.util.Log
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.channelFlow
import java.io.ByteArrayOutputStream
import com.example.myapplication.ai.DemucsNano
import com.example.myapplication.ai.WhisperSTT
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.atomic.AtomicReference

/**
 * DubbingPipeline — HYPER-OPTIMIZED streaming pipeline.
 *
 * TARGET PERFORMANCE: Process 3h movie in 2.5h = 1.2x real-time speed
 * TARGET BATTERY: 20% battery consumption for 3h movie = 6.7% per hour
 *
 * ALL features active:
 *   • Dubbing:    STT → translate → TTS  (real audio)
 *   • BGM:        Demucs stem separation (selective) + AdvancedAudioMixer ducking
 *   • Song align: SongAligner pitch/rhythm warp
 *   • Lip sync:   RealLipSync (geometry) with smart skip; TFLite when available
 *   • HD upscale: RealUpscaler (Lanczos) with smart skip; TFLite when available
 *   • Streaming:  emits DubbingChunk every 2s for live preview
 *   • Parallel:   Audio + Video processing in parallel pipelines
 *   • Smart cache: Reuse stems, translations, and TTS across chunks
 */
/**
 * DubbingPipeline: The orchestration engine for on-device video dubbing.
 *
 * This class coordinates the end-to-end process of extracting audio, separating stems,
 * transcribing speech, translating text, and synthesizing new vocal tracks while
 * maintaining synchronization with the original video.
 *
 * Key features:
 * - Chunk-based streaming for minimal latency.
 * - Resource-aware scheduling (NPU/GPU/CPU).
 * - Multi-layer caching for performance optimization.
 */
class DubbingPipeline(private val context: Context) {
    private val TAG = "DubbingPipeline"
    companion object {
        const val SR  = 16000; const val BPS = 32000
        const val CHUNK_MS = 2000L // 2 second chunks for smooth streaming
        const val PREFETCH_CHUNKS = 3 // Prefetch 3 chunks (6s) ahead
    }

    private val perf        get() = ModelManager.performanceManager
    private val recovery    get() = ModelManager.recoveryManager
    private val stability   get() = ModelManager.stabilityGuard
    val videoProcessor      get() = ModelManager.videoProcessor
    val videoExportEngine   by lazy { VideoExportEngine(context, videoProcessor) }

    // Performance monitoring
    private val processingTimes = mutableListOf<Long>()
    private var totalChunksProcessed = 0
    private var pipelineStartTime = 0L

    enum class State { IDLE, PROCESSING, DONE, FAILED }
    var currentState = State.IDLE; private set
    private val clock = PipelineClock()

    // Smart caching for performance
    private val translationCache = mutableMapOf<String, String>()
    private val stemCache = mutableMapOf<Int, DemucsNano.AudioStems>()
    private var lastDemucsSeparation = -1

    // ── Main entry point ──────────────────────────────────────────────────────
    /**
     * Executes the dubbing process for a given video segment.
     */
    fun processVideoStreaming(uri: String, targetLang: String): Flow<DubbingChunk> =
        channelFlow {
        Log.i(TAG, "START uri=$uri lang=$targetLang")
        ModelManager.awaitReadiness(context)
        stability.incrementCrashCount(); clock.reset()
        currentState = State.PROCESSING

        try {
            // 1. Resolve input file
            send(DubbingChunk(ByteArray(0), 0.02f, false, "Resolving input…"))
            val file = resolveInput(uri)
            check(file.exists() && file.length() > 0) { "Input missing: ${file.path}" }
            Log.i(TAG, "Input: ${file.length()}B")

            // 2. Acquire all models
            val stt        = ModelManager.getWhisper(context)
            val demucs     = ModelManager.getDemucs(context)
            val translator = ModelManager.getTranslator(context)
            val kokoro     = ModelManager.getKokoro(context)
            val segBuilder = runCatching { ModelManager.getSegmentBuilder(context) }.getOrNull()
            stt.initialize(perf.getRecommendedMode() != PowerEfficiencyManager.PowerMode.PERFORMANCE)

            // 3. Duration
            val extractor = LocalAudioExtractor(context)
            val totalMs   = extractor.getDurationMs(file)
            check(totalMs > 0) { "Duration=0, unsupported format" }
            Log.i(TAG, "Duration: ${totalMs}ms")
            
            // OPTIMIZATION: Inform PowerManager about duration to trigger Eco Mode if needed
            ModelManager.performanceManager.setContentDuration(totalMs)

            // 4. Parallel video export job
            val allSegs     = CopyOnWriteArrayList<DubbingSegment>()
            val finalBuf    = ByteArrayOutputStream()
            val latestAudio = AtomicReference(ByteArray(0))
            var audioDone   = false
            var videoPath: String? = null
            val outVideo    = File(context.cacheDir, "dubbed_${System.currentTimeMillis()}.mp4")

            val exportJob = launch(Dispatchers.Default) {
                runCatching {
                    videoExportEngine.export(
                        videoFile=file, audioProvider={latestAudio.get()},
                        isAudioCompleteProvider={audioDone}, outputFile=outVideo, segments=allSegs,
                        onProgress={p->trySend(DubbingChunk(ByteArray(0),0.5f+p*0.45f,false,"Rendering ${(p*100).toInt()}%"))},
                        onFrame={bitmap -> 
                            // EMIT LIVE FRAME: 0-byte audio, just the visual update
                            trySend(DubbingChunk(ByteArray(0), 0.5f, false, null, bitmap))
                        }
                    )
                    videoPath=outVideo.absolutePath; Log.i(TAG,"Video export done: $videoPath")
                }.onFailure{Log.e(TAG,"Export failed (audio-only): ${it.message}")}
            }

            // 5. HYPER-OPTIMIZED chunk loop with smart caching and parallel processing
            var curMs=0L; var idx=0
            pipelineStartTime = System.currentTimeMillis()
            
            while(curMs<totalMs && isActive){
                val chunkStartTime = System.currentTimeMillis()
                val prog=0.05f+0.45f*(curMs.toFloat()/totalMs)
                send(DubbingChunk(ByteArray(0),prog,false,"Processing ${curMs/1000}s…"))

                // 5a. Extract raw PCM
                val rawPcm=extractor.extractAudioChunk(file,curMs,CHUNK_MS)
                if(rawPcm.isEmpty()){curMs+=CHUNK_MS; idx++; continue}

                // 5b. SMART Demucs: Only separate stems when interval allows (PERFORMANCE BOOST)
                val shouldSeparateStems = perf.shouldProcessAIFeature(idx, "DEMUCS")
                val stems = if (shouldSeparateStems) {
                    runCatching{demucs.separateStems(rawPcm)}
                        .getOrElse{DemucsNano.AudioStems(rawPcm,ByteArray(0),ByteArray(0),ByteArray(0))}
                        .also { stemCache[idx] = it; lastDemucsSeparation = idx }
                } else {
                    // Reuse last separated stems for BGM (vocals still need fresh processing)
                    val lastStems = stemCache[lastDemucsSeparation]
                    if (lastStems != null) {
                        DemucsNano.AudioStems(rawPcm, lastStems.bgm, ByteArray(0), ByteArray(0))
                    } else {
                        DemucsNano.AudioStems(rawPcm,ByteArray(0),ByteArray(0),ByteArray(0))
                    }
                }
                val vocals=if(stems.vocals.isNotEmpty()) stems.vocals else rawPcm
                val bgm=stems.bgm

                // 5c. STT — hard fail
                val segs=stt.transcribe(vocals).getOrThrow()
                val durSec=rawPcm.size.toFloat()/BPS
                val toDub=segs.ifEmpty{listOf(DubbingSegment(0f,durSec,""))}
                val offset=curMs/1000f

                // 5d. Per-segment: CACHED translation + TTS + song alignment
                val chunkPcm=ByteArrayOutputStream()
                for(seg in toDub){
                    // SMART CACHE: Check translation cache first
                    val cacheKey = "${seg.text}:$targetLang"
                    val xlated = if(seg.text.isBlank()) ""
                    else translationCache.getOrPut(cacheKey) {
                        runCatching{translator.translate(seg.text,targetLang)}.getOrElse{seg.text}
                    }
                    
                    val speakText=xlated.ifBlank{seg.text}
                    val rawTts=if(speakText.isNotBlank()){
                        runCatching{
                            segBuilder?.build(seg.copy(text=speakText),VoiceProfile.NEUTRAL,vocals,null,1f)
                                ?: kokoro.speak(speakText,VoiceProfile.NEUTRAL,Emotion.NEUTRAL,1f)
                        }.getOrElse{ByteArray(0)}
                    } else ByteArray(0)

                    // Song alignment: warp TTS to match original vocal rhythm/pitch
                    val songAligned=if(rawTts.isNotEmpty() && vocals.isNotEmpty())
                        runCatching{SongAligner(context).align(rawTts,vocals)}.getOrElse{rawTts}
                    else rawTts

                    val targetBytes=((seg.end-seg.start)*BPS).toInt()
                    val stretched=if(songAligned.isNotEmpty()&&targetBytes>0)
                        timeStretch(songAligned,targetBytes) else songAligned
                    chunkPcm.write(stretched)
                    allSegs.add(seg.copy(start=seg.start+offset,end=seg.end+offset))
                }

                // 5e. Professional BGM mix with sidechain ducking (only when we have BGM)
                val dubbed=chunkPcm.toByteArray()
                val mixed=if(bgm.isNotEmpty()){
                    val prosody=ProsodyAnalyzer.analyze(dubbed,"")
                    AdvancedAudioMixer.mix(
                        listOf(
                            AdvancedAudioMixer.AudioTrack(dubbed,1.0f,true),
                            AdvancedAudioMixer.AudioTrack(bgm,0.6f,false)
                        ),
                        perf.getRecommendedMode(), prosody.intensity
                    )
                } else dubbed

                // 5f. Accumulate + emit streaming chunk
                finalBuf.write(mixed); latestAudio.set(finalBuf.toByteArray())
                
                // Performance monitoring
                val chunkTime = System.currentTimeMillis() - chunkStartTime
                processingTimes.add(chunkTime)
                if (processingTimes.size > 30) processingTimes.removeAt(0)
                val avgChunkTime = processingTimes.average().toLong()
                val speedMultiplier = CHUNK_MS.toFloat() / avgChunkTime
                
                Log.i(TAG,"Chunk $idx: ${chunkTime}ms (avg: ${avgChunkTime}ms, speed: ${String.format("%.2f", speedMultiplier)}x) | ${mixed.size}B")
                perf.recordFrameProcessTime(chunkTime)
                
                send(DubbingChunk(mixed,prog,false,"Live preview (${String.format("%.1f", speedMultiplier)}x speed)"))
                recovery.saveQuickCheckpoint("DUBBING",(curMs.toFloat()/totalMs)*100)
                
                // Clean up old cache entries to prevent memory bloat
                if (stemCache.size > 10) {
                    val oldestKey = stemCache.keys.minOrNull()
                    if (oldestKey != null && oldestKey < idx - 5) {
                        stemCache.remove(oldestKey)
                    }
                }
                
                curMs+=CHUNK_MS; idx++; totalChunksProcessed++
            }

            audioDone=true; exportJob.join()
            
            // Performance summary
            val totalTime = System.currentTimeMillis() - pipelineStartTime
            val speedMultiplier = (totalMs.toFloat() / totalTime)
            val avgChunkTime = processingTimes.average()
            Log.i(TAG, "═══════════════════════════════════════════════════════════")
            Log.i(TAG, "PIPELINE COMPLETE - PERFORMANCE SUMMARY")
            Log.i(TAG, "Total movie duration: ${totalMs/1000}s (${totalMs/60000}m)")
            Log.i(TAG, "Total processing time: ${totalTime/1000}s (${totalTime/60000}m)")
            Log.i(TAG, "Processing speed: ${String.format("%.2f", speedMultiplier)}x real-time")
            Log.i(TAG, "Target: 1.2x | Achieved: ${if(speedMultiplier >= 1.2f) "✓ YES" else "✗ NO (${String.format("%.1f", (speedMultiplier/1.2f)*100)}%)"}")
            Log.i(TAG, "Chunks processed: $totalChunksProcessed")
            Log.i(TAG, "Avg chunk time: ${avgChunkTime.toLong()}ms")
            Log.i(TAG, "Translation cache hits: ${translationCache.size}")
            Log.i(TAG, "Stem reuse count: ${idx - stemCache.size}")
            Log.i(TAG, "═══════════════════════════════════════════════════════════")
            
            // Aggressive cleanup to free memory
            translationCache.clear()
            stemCache.clear()
            processingTimes.clear()
            System.gc()

            // 6. Verify output
            val fullPcm=finalBuf.toByteArray()
            check(fullPcm.isNotEmpty()){"Pipeline produced 0 audio bytes"}
            Log.i(TAG,"Audio total: ${fullPcm.size}B | Video: ${videoPath?:"none"}")
            currentState=State.DONE
            send(DubbingChunk(fullPcm,1f,true,videoPath?:"AUDIO_ONLY"))

        } catch(e:Exception){
            currentState=State.FAILED; Log.e(TAG,"FAILED: ${e.message}",e); throw e
        }
    }

    fun addWavHeaderLocal(pcm:ByteArray,sr:Int,ch:Int):ByteArray{
        val dl=pcm.size; val bb=java.nio.ByteBuffer.allocate(44).order(java.nio.ByteOrder.LITTLE_ENDIAN)
        bb.put("RIFF".toByteArray());bb.putInt(dl+36);bb.put("WAVE".toByteArray())
        bb.put("fmt ".toByteArray());bb.putInt(16);bb.putShort(1);bb.putShort(ch.toShort())
        bb.putInt(sr);bb.putInt(sr*ch*2);bb.putShort((ch*2).toShort());bb.putShort(16)
        bb.put("data".toByteArray());bb.putInt(dl); return bb.array()+pcm
    }

    private suspend fun resolveInput(uri:String):File=withContext(Dispatchers.IO){
        when{ uri.startsWith("http")->dlUrl(uri)
            else->{val p=Uri.parse(uri); if(p.scheme=="content") copyContent(p) else File(uri)} }
    }
    private fun dlUrl(url:String):File{
        val out=File(context.cacheDir,"dl_${System.currentTimeMillis()}.mp4")
        val c=URL(url).openConnection() as HttpURLConnection
        c.connectTimeout=30000;c.readTimeout=30000;c.connect()
        c.inputStream.use{i->FileOutputStream(out).use{i.copyTo(it)}};c.disconnect(); return out
    }
    private fun copyContent(uri:Uri):File{
        val out=File(context.cacheDir,"uri_${System.currentTimeMillis()}.mp4")
        context.contentResolver.openInputStream(uri)?.use{i->FileOutputStream(out).use{i.copyTo(it)}}; return out
    }
    private fun timeStretch(input: ByteArray, targetBytes: Int): ByteArray {
        if (input.isEmpty() || targetBytes <= 0) return input
        val al = targetBytes and 1.inv(); val out = ByteArray(al)
        for (i in 0 until al / 2) {
            val si = ((i.toLong() * (input.size / 2)) / (al / 2)).coerceIn(0, (input.size / 2 - 1).toLong()).toInt()
            out[i * 2] = input[si * 2]; out[i * 2 + 1] = input[si * 2 + 1]
        }
        return out
    }
}
