package com.example.myapplication.core

import android.content.Context
import android.util.Log
import kotlin.math.max
import kotlin.math.min

/**
 * Experimental Song Aligner (Phase-6).
 * Aligns dubbed vocals to songs using pitch-shifting and rhythmic warping.
 * SAFETY: Identity cloning is strictly disabled for singing to prevent deepfakes.
 */
class SongAligner(private val context: Context) {
    private val TAG = "SongAligner"

    /**
     * Aligns a dubbed vocal DubbingSegment to its original singing counterpart.
     * Uses pitch-agnostic time stretching and basic resampling for pitch matching.
     */
    fun align(dubbedVocal: ByteArray, originalSinging: ByteArray): ByteArray {
        if (dubbedVocal.isEmpty() || originalSinging.isEmpty()) return dubbedVocal

        Log.i(TAG, "Aligning vocal to song melody. Mode: Pitch-Safe.")
        
        // 1. Detect Average Pitch of Original Singing (Heuristic)
        val targetPitch = estimatePitch(originalSinging)
        val sourcePitch = estimatePitch(dubbedVocal)
        
        // 2. Simple Resampling for Pitch Correction
        val pitchRatio = if (sourcePitch > 0) targetPitch / sourcePitch else 1.0f
        val pitchCorrected = resampleForPitch(dubbedVocal, pitchRatio)
        
        // 3. Rhythmic Warping (Time Stretch to match duration)
        return timeStretch(pitchCorrected, originalSinging.size)
    }

    private fun estimatePitch(pcm: ByteArray): Float {
        // Simple Zero-Crossing Rate (ZCR) as a proxy for pitch frequency
        var crossings = 0
        for (i in 2 until pcm.size step 2) {
            val curr = (pcm[i+1].toInt() shl 8) or (pcm[i].toInt() and 0xFF)
            val prev = (pcm[i-1].toInt() shl 8) or (pcm[i-2].toInt() and 0xFF)
            if ((curr > 0 && prev < 0) || (curr < 0 && prev > 0)) {
                crossings++
            }
        }
        val duration = pcm.size / 32000f
        return if (duration > 0) crossings / (2 * duration) else 0f
    }

    private fun resampleForPitch(input: ByteArray, ratio: Float): ByteArray {
        if (ratio == 1.0f) return input
        
        val newSize = (input.size / ratio).toInt() and -2 // Ensure even size
        val output = ByteArray(newSize)
        
        for (i in 0 until (newSize / 2)) {
            val inputPos = (i * ratio).toInt() * 2
            if (inputPos < input.size - 1) {
                output[i * 2] = input[inputPos]
                output[i * 2 + 1] = input[inputPos + 1]
            }
        }
        return output
    }

    private fun timeStretch(input: ByteArray, targetSize: Int): ByteArray {
        // Linear interpolation for time-stretching
        val output = ByteArray(targetSize)
        val ratio = input.size.toDouble() / targetSize.toDouble()
        
        for (i in 0 until (targetSize / 2)) {
            val srcIdx = (i * ratio).toInt() * 2
            if (srcIdx < input.size - 1) {
                output[i * 2] = input[srcIdx]
                output[i * 2 + 1] = input[srcIdx + 1]
            }
        }
        return output
    }
}
