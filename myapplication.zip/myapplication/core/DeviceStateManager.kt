package com.example.myapplication.core

import android.content.Context
import android.os.BatteryManager
import android.os.PowerManager
import android.util.Log

/**
 * DeviceStateManager: Real-time Power & Thermal Governor.
 * Dynamically throttles high-compute tasks to prevent device overheating and battery drain.
 */
object DeviceStateManager {

    fun isLowPower(context: Context): Boolean {
        val bm = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val battery = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)

        val powerManager = context.getSystemService(Context.POWER_SERVICE) as PowerManager
        val saverOn = powerManager.isPowerSaveMode

        return battery <= 20 || saverOn
    }

    /**
     * Recommended FPS for the video export engine based on device state.
     * Prevents thermal throttling during long renders.
     */
    fun recommendedFps(context: Context): Int {
        return if (isLowPower(context)) 12 else 24
    }

    /**
     * Strategic Delegate Decision: CPU is more power-efficient for small models 
     * when the battery is critical, as NPU/GPU startup overhead is high.
     */
    fun shouldUseHardwareAcceleration(context: Context): Boolean {
        return !isLowPower(context)
    }
}
