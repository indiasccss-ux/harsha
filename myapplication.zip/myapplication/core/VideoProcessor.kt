package com.example.myapplication.core

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Rect
import android.util.Log
import com.example.myapplication.RealLipSync
import com.example.myapplication.RealUpscaler
import com.example.myapplication.core.ModelManager
import com.example.myapplication.core.PowerEfficiencyManager
import com.example.myapplication.core.Emotion
import com.example.myapplication.core.MouthCropManager

/**
 * VideoProcessor — orchestrates RealLipSync + RealUpscaler per frame.
 *
 * LipSync:  REAL — geometry-driven mouth animation from audio energy.
 *           Upgrade: add latentsync-lipsync.tflite → neural sync activates.
 * Upscaling: REAL — Lanczos 2× + unsharp mask.
 *           Upgrade: add real-esrgan-4k.tflite → AI super-res activates.
 */
class VideoProcessor(private val context: Context) {
    private val TAG = "VideoProcessor"
    private val perf get() = ModelManager.performanceManager

    fun getPowerMode() = perf.getRecommendedMode()

    fun release() {
        // Cleanup resources if needed
    }

    suspend fun processFrame(
        frameBitmap: Bitmap,
        audioPcm: FloatArray,
        emotion: Emotion,
        frameIndex: Int,
        faceBounds: Rect? = null
    ): Bitmap {
        val mode = perf.getRecommendedMode()

        // ── Step 1: Lip Sync ───────────────────────────────────────────────
        val lipSynced = try {
            // Try TFLite LatentSync if model loaded
            val ls = ModelManager.getLipSync(context)
            if (ls.isModelAvailable() && audioPcm.size >= 80) {
                val mouthMgr = MouthCropManager()
                val mouthCtx = mouthMgr.extractMouth(frameBitmap, faceBounds)
                if (mouthCtx != null) {
                    val mouthBuf = java.nio.ByteBuffer.allocateDirect(96*96*4)
                        .order(java.nio.ByteOrder.nativeOrder())
                    mouthCtx.croppedMouth.copyPixelsToBuffer(mouthBuf)
                    val syncedBuf = ls.syncLips(mouthBuf, audioPcm, emotion)
                    val syncedBmp = Bitmap.createBitmap(96, 96, Bitmap.Config.ARGB_8888)
                    syncedBuf.rewind(); syncedBmp.copyPixelsFromBuffer(syncedBuf)
                    mouthMgr.blendMouth(frameBitmap, syncedBmp, mouthCtx)
                } else frameBitmap
            } else {
                // Fallback: geometry-based real lip sync
                RealLipSync.applyToFrame(frameBitmap, audioPcm, emotion)
            }
        } catch (e: Exception) {
            // Geometry fallback on any TFLite error
            runCatching { RealLipSync.applyToFrame(frameBitmap, audioPcm, emotion) }
                .getOrDefault(frameBitmap)
        }

        // ── Step 2: Upscaling ──────────────────────────────────────────────
        val upscaled = try {
            val up = ModelManager.getUpscaler(context)
            if (up.isModelAvailable() && !perf.isUpscalingForbidden()) {
                // TFLite AI upscaler path
                val byteCount = lipSynced.byteCount
                val buf = java.nio.ByteBuffer.allocateDirect(byteCount)
                    .order(java.nio.ByteOrder.nativeOrder())
                lipSynced.copyPixelsToBuffer(buf); buf.rewind()
                val outBuf = up.upscale(buf, frameIndex)
                if (outBuf !== buf) {
                    val ow = lipSynced.width * 2; val oh = lipSynced.height * 2
                    Bitmap.createBitmap(ow, oh, Bitmap.Config.ARGB_8888).also {
                        outBuf.rewind(); it.copyPixelsFromBuffer(outBuf)
                    }
                } else lipSynced
            } else {
                // Lanczos 2× real upscaler
                RealUpscaler.upscale(lipSynced, mode, frameIndex)
            }
        } catch (e: Exception) {
            runCatching { RealUpscaler.upscale(lipSynced, mode, frameIndex) }
                .getOrDefault(lipSynced)
        }

        return upscaled
    }
}
