package com.example.myapplication.core

/**
 * PipelineClock: High-precision relative timestamp tracker.
 * Ensures that audio, visual, and AI inference chunks stay perfectly aligned.
 */
class PipelineClock {
    private var startTime = System.nanoTime()

    /**
     * Returns the elapsed time in milliseconds since the last reset.
     */
    fun timestamp(): Long {
        return (System.nanoTime() - startTime) / 1_000_000
    }

    /**
     * Resets the clock to the current moment.
     */
    fun reset() {
        startTime = System.nanoTime()
    }
}
