package com.example.myapplication.core

import android.content.Context
import android.util.Log
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.sync.Mutex
import com.example.myapplication.ai.WhisperSTT
import com.example.myapplication.ai.KokoroTTS
import com.example.myapplication.ai.DemucsNano
import com.example.myapplication.ai.LatentSyncMicro
import com.example.myapplication.ai.RealESRANTernary
import com.example.myapplication.ai.ClonedVocalEngine
import com.example.myapplication.ai.ModelSwapper
import com.example.myapplication.ai.InferenceEngine
import kotlinx.coroutines.sync.withLock

object ModelManager {
    private const val TAG = "ModelManager"
    enum class ModelState { UNINITIALIZED, LOADING, READY, ERROR }

    private val _state = MutableStateFlow(ModelState.UNINITIALIZED)
    val state: StateFlow<ModelState> = _state
    private val mutex = Mutex()

    var sttReady=false; private set; var ttsReady=false; private set
    var demucsReady=false; private set; var lipSyncReady=false; private set
    var upscalerReady=false; private set; var isLoaded=false; private set; var isLoading=false; private set

    private var whisper: WhisperSTT?=null; private var kokoro: KokoroTTS?=null
    private var demucs: DemucsNano?=null; private var lipSync: LatentSyncMicro?=null
    private var upscaler: RealESRANTernary?=null; private var translator: BhashaRupantarika?=null
    private var clonedEngine: ClonedVocalEngine?=null; private var segBuilder: DubbingSegmentAudioBuilder?=null

    private var _ms: ModelSwapper?=null; private var _pm: PowerEfficiencyManager?=null
    private var _sg: StabilityGuard?=null; private var _cr: CrashRecoveryManager?=null
    private var _vp: VideoProcessor?=null; private var _prof: VoiceProfileManager?=null
    private var _ve: VisemeTimingEngine?=null; private var _ie: InferenceEngine?=null

    val modelSwapper          get()=_ms!!; val sharedInferenceEngine get()=_ie!!
    val performanceManager    get()=_pm!!; val stabilityGuard        get()=_sg!!
    val recoveryManager       get()=_cr!!; val videoProcessor        get()=_vp!!
    val profileManager        get()=_prof!!; val visemeTimingEngine  get()=_ve!!

    fun preloadAll(ctx: Context) {
        val c=ctx.applicationContext
        if(_ms==null)   _ms   =ModelSwapper(c)
        if(_pm==null)   _pm   =PowerEfficiencyManager(c)
        if(_ie==null)   _ie   =InferenceEngine(c)
        if(_sg==null)   _sg   =StabilityGuard(c)
        if(_cr==null)   _cr   =CrashRecoveryManager(c)
        if(_vp==null)   _vp   =VideoProcessor(c)
        if(_prof==null) _prof =VoiceProfileManager(c)
        if(_ve==null)   _ve   =VisemeTimingEngine(c)
        Log.i(TAG,"Infrastructure ready")
    }

    // Fixed race: waits while LOADING before loading again
    suspend fun awaitReadiness(ctx: Context, timeoutMs: Long=120_000) {
        if(_state.value==ModelState.READY) return
        withTimeout(timeoutMs) {
            while(_state.value==ModelState.LOADING) delay(200)
            if(_state.value!=ModelState.READY)
                mutex.withLock { if(_state.value!=ModelState.READY) loadDubbingModels(ctx) }
            _state.first{it==ModelState.READY||it==ModelState.ERROR}
        }
        if(_state.value==ModelState.ERROR)
            throw IllegalStateException("AI stack ERROR — STT=$sttReady TTS=$ttsReady")
    }

    suspend fun getWhisper(ctx:Context):WhisperSTT=awaitGet(ctx){whisper!!}
    suspend fun getKokoro(ctx:Context):KokoroTTS=awaitGet(ctx){kokoro!!}
    suspend fun getDemucs(ctx:Context):DemucsNano=awaitGet(ctx){demucs!!}
    suspend fun getLipSync(ctx:Context):LatentSyncMicro=awaitGet(ctx){lipSync!!}
    suspend fun getUpscaler(ctx:Context):RealESRANTernary=awaitGet(ctx){upscaler!!}
    suspend fun getTranslator(ctx:Context):BhashaRupantarika=awaitGet(ctx){translator!!}
    suspend fun getSegmentBuilder(ctx:Context):DubbingSegmentAudioBuilder=awaitGet(ctx){segBuilder!!}
    suspend fun getClonedEngine(ctx:Context):ClonedVocalEngine=awaitGet(ctx){clonedEngine!!}
    private suspend fun <T> awaitGet(ctx:Context,block:()->T):T{awaitReadiness(ctx);return block()}

    suspend fun loadDubbingModels(ctx: Context)=withContext(Dispatchers.Default){
        val appContext = ctx.applicationContext
        mutex.withLock {
            if(isLoaded||_state.value==ModelState.READY) return@withContext
            _state.value=ModelState.LOADING; isLoading=true
            sttReady=false;ttsReady=false;demucsReady=false;lipSyncReady=false;upscalerReady=false
            preloadAll(appContext); Log.i(TAG,"Loading AI stack…")
            try {
                // CRITICAL — throws on failure, no silent fallback
                whisper=WhisperSTT(appContext,_ie!!,_ms!!).also{it.warmup()}
                sttReady=true; Log.i(TAG,"STT ready")
                kokoro=KokoroTTS(appContext); delay(300); ttsReady=true; Log.i(TAG,"TTS ready")
                // OPTIONAL — warn and continue
                demucs=runCatching{DemucsNano(appContext,_ms!!,_ie!!).also{it.warmup()}}
                    .getOrElse{Log.w(TAG,"Demucs: ${it.message}");null}; demucsReady=demucs!=null
                translator=BhashaRupantarika(appContext,_ms!!,_ie!!)
                lipSync=runCatching{LatentSyncMicro(appContext,_ie!!,_ms!!).also{it.warmup()}}
                    .getOrElse{Log.w(TAG,"LipSync TFLite: ${it.message}");null}; lipSyncReady=lipSync!=null
                upscaler=runCatching{RealESRANTernary(appContext,_ie!!,_ms!!,_pm!!).also{it.warmup()}}
                    .getOrElse{Log.w(TAG,"Upscaler TFLite: ${it.message}");null}; upscalerReady=upscaler!=null
                clonedEngine=runCatching{ClonedVocalEngine(appContext,kokoro!!,_ms!!)}.getOrNull()
                segBuilder=clonedEngine?.let{runCatching{DubbingSegmentAudioBuilder(appContext,it)}.getOrNull()}
                check(sttReady&&ttsReady){"Critical: STT=$sttReady TTS=$ttsReady"}
                isLoaded=true; _state.value=ModelState.READY
                Log.i(TAG,"READY | STT=$sttReady TTS=$ttsReady Demucs=$demucsReady LipSync(TFLite)=$lipSyncReady Upscaler(TFLite)=$upscalerReady | LipSync(Geo)=ALWAYS | Upscaler(Lanczos)=ALWAYS")
            } catch(e:Exception){ Log.e(TAG,"FAILED: ${e.message}",e); _state.value=ModelState.ERROR; throw e }
            finally { isLoading=false }
        }
    }

    fun isReady()=_state.value==ModelState.READY

    fun releaseAll(){
        whisper?.release();whisper=null;kokoro?.release();kokoro=null
        demucs=null;lipSync=null;upscaler=null
        translator?.releaseAll();translator=null
        clonedEngine=null;segBuilder=null
        _ie?.release();_ie=null;_ms=null;_pm=null;_sg=null;_cr=null;_vp=null;_prof=null;_ve=null
        isLoaded=false;sttReady=false;ttsReady=false;demucsReady=false;lipSyncReady=false;upscalerReady=false
        _state.value=ModelState.UNINITIALIZED; Log.i(TAG,"All released")
    }
}
