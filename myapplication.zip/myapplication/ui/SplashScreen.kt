package com.example.myapplication.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

@Composable
fun SplashScreen(onAnimationFinished: () -> Unit) {
    var startAnimation by remember { mutableStateOf(false) }
    
    // Fade in text and zoom
    val contentAlpha by animateFloatAsState(
        targetValue = if (startAnimation) 1f else 0f,
        animationSpec = tween(durationMillis = 1500, easing = FastOutSlowInEasing),
        label = "contentAlpha"
    )
    
    val contentScale by animateFloatAsState(
        targetValue = if (startAnimation) 1.2f else 1.0f,
        animationSpec = tween(durationMillis = 4000, easing = LinearEasing),
        label = "contentScale"
    )

    // Letterboxing animation (Movie style)
    val letterboxHeight by animateDpAsState(
        targetValue = if (startAnimation) 80.dp else 0.dp,
        animationSpec = tween(durationMillis = 1000, easing = FastOutSlowInEasing),
        label = "letterbox"
    )

    // Infinite pulsing background glow
    val infiniteTransition = rememberInfiniteTransition(label = "infinite")
    val glowAlpha by infiniteTransition.animateFloat(
        initialValue = 0.2f,
        targetValue = 0.5f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glowAlpha"
    )

    LaunchedEffect(Unit) {
        startAnimation = true
        delay(3500) // Stay long enough for the cinematic feel
        onAnimationFinished()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black),
        contentAlignment = Alignment.Center
    ) {
        // Red Cinematic Glow
        Box(
            modifier = Modifier
                .fillMaxSize()
                .alpha(glowAlpha)
                .background(
                    Brush.radialGradient(
                        colors = listOf(Color(0xFFEF4444).copy(alpha = 0.4f), Color.Black),
                        radius = 1200f
                    )
                )
        )

        // Contents
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .alpha(contentAlpha)
                .scale(contentScale)
        ) {
            Text(
                text = "Bhasha AI",
                fontSize = 54.sp,
                fontWeight = FontWeight.Black,
                color = Color(0xFFEF4444), // Movie Red
                letterSpacing = 12.sp
            )
            
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = "AI DUBBING",
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                color = Color.White.copy(alpha = 0.7f),
                letterSpacing = 16.sp
            )
        }

        // Letterboxing (Top & Bottom bars)
        Column(modifier = Modifier.fillMaxSize()) {
            Box(modifier = Modifier.fillMaxWidth().height(letterboxHeight).background(Color.Black))
            Spacer(modifier = Modifier.weight(1f))
            Box(modifier = Modifier.fillMaxWidth().height(letterboxHeight).background(Color.Black))
        }
    }
}
