package com.example.myapplication.ui


import android.util.Log
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.createSupabaseClient
import io.github.jan.supabase.gotrue.Auth
import io.github.jan.supabase.gotrue.OtpType
import io.github.jan.supabase.gotrue.SessionStatus
import io.github.jan.supabase.gotrue.auth
import io.github.jan.supabase.gotrue.providers.Google
import io.github.jan.supabase.gotrue.providers.builtin.Email
import io.github.jan.supabase.gotrue.providers.builtin.IDToken
import io.github.jan.supabase.gotrue.providers.builtin.OTP
import io.github.jan.supabase.postgrest.Postgrest
import io.github.jan.supabase.postgrest.postgrest
import io.github.jan.supabase.postgrest.from
import com.example.myapplication.ui.UserDto
import kotlinx.coroutines.flow.first
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import kotlinx.serialization.json.JsonPrimitive

/**
 * Central Authentication Manager.
 * Handles Supabase Client (Auth + Database).
 * Replaces Google Sign-In with Email/Password.
 */
object AppAuth {

    private const val SUPABASE_URL = "https://gavfafssgvckjblmjhcg.supabase.co"
    private const val SUPABASE_KEY = "sb_publishable_MXQbIydQi3nUwFLAez3VIQ_JjKiW7o5"

    val client: SupabaseClient by lazy {
        createSupabaseClient(
            supabaseUrl = SUPABASE_URL,
            supabaseKey = SUPABASE_KEY
        ) {
            httpEngine = io.ktor.client.engine.okhttp.OkHttp.create()
            install(Auth) {
                alwaysAutoRefresh = true
            }
            install(Postgrest)
        }
    }

    suspend fun signInWithEmail(email: String, password: String): Result<Boolean> {
        return try {
            client.auth.signInWith(Email) {
                this.email = email
                this.password = password
            }

            client.auth.sessionStatus.first { it is SessionStatus.Authenticated }
            Log.i("AppAuth", "Sign-In Successful! Saving user to DB...")
            saveUserToDatabase()
            Result.success(true)

        } catch (e: Exception) {
            Log.e("AppAuth", "Sign-In Failed: ${e.message}")
            Result.failure(e)
        }
    }

    suspend fun signUpWithEmail(email: String, password: String, fullName: String): Result<Boolean> {
        return try {
            client.auth.signUpWith(Email) {
                this.email = email
                this.password = password
                // Configurable metadata
                data = kotlinx.serialization.json.buildJsonObject {
                     put("full_name", kotlinx.serialization.json.JsonPrimitive(fullName))
                }
            }

            Log.i("AppAuth", "Sign-Up Successful! Check email for confirmation if enabled.")

            if (client.auth.currentUserOrNull() != null) {
                saveUserToDatabase()
                Result.success(true)
            } else {
                // If auto-confirm is off, they aren't logged in yet, but signup was success
                Result.success(true) 
            }

        } catch (e: Exception) {
            Log.e("AppAuth", "Sign-Up Failed: ${e.message}")
            Result.failure(e)
        }
    }

    suspend fun signInWithGoogleIdToken(idToken: String): Result<Boolean> {
        return try {
            client.auth.signInWith(IDToken) {
                this.idToken = idToken
                this.provider = Google
            }

            client.auth.sessionStatus.first { it is SessionStatus.Authenticated }
            Log.i("AppAuth", "Google Sign-In Successful!")
            saveUserToDatabase()
            Result.success(true)

        } catch (e: Exception) {
            Log.e("AppAuth", "Google Sign-In Failed: ${e.message}")
            Result.failure(e)
        }
    }


    suspend fun verifyEmailOTP(email: String, token: String): Result<Boolean> {
        return try {
            Log.d("AppAuth", "Verifying Email OTP for $email with token: $token")
            client.auth.verifyEmailOtp(
                email = email,
                token = token,
                type = OtpType.Email.SIGNUP
            )
            Log.i("AppAuth", "Email OTP Verified! User logged in.")
            saveUserToDatabase()
            Result.success(true)
        } catch (e: Exception) {
            Log.e("AppAuth", "Email OTP Verification Failed: ${e.message}")
            Result.failure(e)
        }
    }

    private suspend fun saveUserToDatabase() {
        try {
            val user = client.auth.currentUserOrNull() ?: return
            val meta = user.userMetadata

            val userDto = UserDto(
                id = user.id,
                email = user.email,
                fullName = meta?.get("full_name")?.toString()
                    ?: meta?.get("name")?.toString(),
                avatarUrl = meta?.get("avatar_url")?.toString()
            )

            client.postgrest["users"].upsert(userDto)
            Log.d("AppAuth", "User data saved to Supabase 'users' table")

        } catch (e: Exception) {
            Log.e("AppAuth", "Failed to save user to DB: ${e.message}")
        }
    }


    suspend fun resetPasswordForEmail(email: String): Result<Boolean> {
        return try {
            client.auth.resetPasswordForEmail(email)
            Log.i("AppAuth", "Password Reset Email Sent to $email")
            Result.success(true)

        } catch (e: Exception) {
            Log.e("AppAuth", "Password Reset Failed: ${e.message}")
            Result.failure(e)
        }
    }

    suspend fun signOut() {
        client.auth.signOut()
    }

    fun getCurrentUser() = client.auth.currentUserOrNull()
}
