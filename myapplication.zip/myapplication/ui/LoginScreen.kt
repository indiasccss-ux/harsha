package com.example.myapplication.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

import androidx.credentials.CredentialManager
import androidx.credentials.GetCredentialRequest
import androidx.credentials.GetCredentialResponse
import androidx.credentials.exceptions.GetCredentialException
import androidx.credentials.CustomCredential
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential

@Composable
fun LoginScreen(
    isDarkMode: Boolean,
    onLoginSuccess: () -> Unit,
    onNavigateToSignup: () -> Unit,
    onGuestLogin: () -> Unit
) {
    val scope = rememberCoroutineScope()
    var isLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var isPasswordVisible by remember { mutableStateOf(false) }

    // Background Colors
    val bgColor1 = if (isDarkMode) Color(0xFF000000) else Color(0xFFFFFFFF)
    val bgColor2 = if (isDarkMode) Color(0xFF450A0A) else Color(0xFFFEE2E2) // Deep Red vs Light Red

    val accentColor =
        if (isDarkMode) Color(0xFFEF4444) else Color(0xFFB91C1C) // Vibrant Red vs Darker Red
    val textColor = if (isDarkMode) Color.White else Color.Black
    val secondaryTextColor =
        if (isDarkMode) Color.White.copy(alpha = 0.6f) else Color.Black.copy(alpha = 0.6f)

    val backgroundBrush = Brush.verticalGradient(
        colors = listOf(bgColor1, bgColor2, bgColor1)
    )

    var cardVisible by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        cardVisible = true
    }

    Box(
        modifier = Modifier.fillMaxSize().background(backgroundBrush),
        contentAlignment = Alignment.Center
    ) {
        androidx.compose.animation.AnimatedVisibility(
            visible = cardVisible,
            enter = androidx.compose.animation.fadeIn(animationSpec = tween(1000)) +
                    androidx.compose.animation.slideInVertically(
                        initialOffsetY = { it / 2 },
                        animationSpec = tween(1000)
                    )
        ) {
            Card(
                modifier = Modifier.fillMaxWidth(0.9f).wrapContentHeight().padding(16.dp),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(
                    containerColor = (if (isDarkMode) Color.White else Color.Black).copy(alpha = 0.05f)
                )
            ) {
                Column(
                    modifier = Modifier.padding(24.dp).fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Logo or Branding
                    Text(
                        "Bhasha AI",
                        fontSize = 32.sp,
                        fontWeight = FontWeight.Bold,
                        color = accentColor
                    )
                    Text(
                        "Welcome Back",
                        style = MaterialTheme.typography.bodyLarge,
                        color = textColor,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                    Text(
                        "Sign in to continue",
                        style = MaterialTheme.typography.bodyMedium,
                        color = secondaryTextColor,
                        modifier = Modifier.padding(top = 4.dp, bottom = 32.dp)
                    )

                    // Email Input
                    OutlinedTextField(
                        value = email,
                        onValueChange = { email = it },
                        label = { Text("Email", color = secondaryTextColor) },
                        leadingIcon = { Icon(Icons.Default.Email, null, tint = accentColor) },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = accentColor,
                            unfocusedBorderColor = textColor.copy(0.2f),
                            focusedTextColor = textColor,
                            unfocusedTextColor = textColor
                        ),
                        singleLine = true
                    )

                    Spacer(Modifier.height(16.dp))

                    // Password Input
                    OutlinedTextField(
                        value = password,
                        onValueChange = { password = it },
                        label = { Text("Password", color = secondaryTextColor) },
                        leadingIcon = { Icon(Icons.Default.Lock, null, tint = accentColor) },
                        trailingIcon = {
                            IconButton(onClick = { isPasswordVisible = !isPasswordVisible }) {
                                Icon(
                                    if (isPasswordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                    null,
                                    tint = secondaryTextColor
                                )
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        visualTransformation = if (isPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = accentColor,
                            unfocusedBorderColor = textColor.copy(0.2f),
                            focusedTextColor = textColor,
                            unfocusedTextColor = textColor
                        ),
                        singleLine = true
                    )

                    Spacer(Modifier.height(24.dp))

                    if (isLoading) {
                        CircularProgressIndicator(color = accentColor)
                    } else {
                        Button(
                            onClick = {
                                if (email.isBlank() || password.isBlank()) {
                                    errorMessage = "Please enter email and password"
                                    return@Button
                                }
                                scope.launch {
                                    isLoading = true
                                    errorMessage = null

                                    val result = AppAuth.signInWithEmail(email, password)
                                    if (result.isSuccess) {
                                        onLoginSuccess()
                                    } else {
                                        errorMessage = result.exceptionOrNull()?.message
                                    }
                                    isLoading = false
                                }
                            },
                            modifier = Modifier.fillMaxWidth().height(50.dp),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = accentColor,
                                contentColor = Color.White
                            )
                        ) {
                            Text("SIGN IN", fontWeight = FontWeight.Bold)
                        }

                        Spacer(Modifier.height(16.dp))

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            HorizontalDivider(
                                modifier = Modifier.weight(1f),
                                color = textColor.copy(0.2f)
                            )
                            Text(" OR ", color = textColor.copy(0.5f), fontSize = 12.sp)
                            HorizontalDivider(
                                modifier = Modifier.weight(1f),
                                color = textColor.copy(0.2f)
                            )
                        }

                        Spacer(Modifier.height(16.dp))

                        // Google Sign-In Button
                        val context = androidx.compose.ui.platform.LocalContext.current
                        val credentialManager =
                            androidx.credentials.CredentialManager.create(context)

                        OutlinedButton(
                            onClick = {
                                scope.launch {
                                    try {
                                        val googleIdOption = GetGoogleIdOption.Builder()
                                            .setFilterByAuthorizedAccounts(false)
                                            .setServerClientId("YOUR_WEB_CLIENT_ID.apps.googleusercontent.com")
                                            .setAutoSelectEnabled(false)
                                            .build()

                                        val request = GetCredentialRequest.Builder()
                                            .addCredentialOption(googleIdOption)
                                            .build()

                                        val result = credentialManager.getCredential(
                                            request = request,
                                            context = context
                                        )

                                        val credential = result.credential
                                        if (credential is CustomCredential && credential.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                                            val googleIdTokenCredential =
                                                GoogleIdTokenCredential.createFrom(credential.data)
                                            val idToken = googleIdTokenCredential.idToken

                                            val authResult =
                                                AppAuth.signInWithGoogleIdToken(idToken)
                                            if (authResult.isSuccess) {
                                                onLoginSuccess()
                                            } else {
                                                errorMessage = authResult.exceptionOrNull()?.message
                                            }
                                        } else {
                                            errorMessage = "Unexpected credential type"
                                        }
                                    } catch (e: GetCredentialException) {
                                        errorMessage = "Google Sign-In failed: ${e.message}"
                                    } catch (e: Exception) {
                                        errorMessage = "Error: ${e.message}"
                                    }
                                }
                            },
                            modifier = Modifier.fillMaxWidth().height(50.dp),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = textColor),
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                textColor.copy(0.5f)
                            )
                        ) {
                            Text(
                                "G",
                                fontWeight = FontWeight.Bold,
                                fontSize = 20.sp,
                                color = accentColor
                            )
                            Spacer(Modifier.width(12.dp))
                            Text("Sign in with Google", fontWeight = FontWeight.SemiBold)
                        }

                        Spacer(Modifier.height(16.dp))

                        TextButton(onClick = onNavigateToSignup) {
                            Text("Don't have an account? Sign Up", color = accentColor)
                        }

                        Spacer(Modifier.height(8.dp))

                        TextButton(onClick = onGuestLogin) {
                            Text("Continue as Guest", color = secondaryTextColor, fontWeight = FontWeight.SemiBold)
                        }
                    }

                    if (errorMessage != null) {
                        Text(
                            errorMessage!!,
                            color = Color.Red,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(top = 16.dp)
                        )
                    }
                }
            }
        }
    }
}




