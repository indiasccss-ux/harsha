package com.example.myapplication.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import android.os.Build
import androidx.compose.animation.core.tween
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.togetherWith
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.viewinterop.AndroidView
import com.example.myapplication.ui.theme.MyApplicationTheme
import io.github.jan.supabase.gotrue.SessionStatus
import io.github.jan.supabase.gotrue.auth
import kotlinx.coroutines.launch
import androidx.lifecycle.lifecycleScope
import java.io.File
import com.example.myapplication.core.DubbingPipeline
import com.example.myapplication.core.ModelManager
import com.example.myapplication.core.DelegateBenchmark

class MainActivity : ComponentActivity() {
    private val dubbingPipeline by lazy { DubbingPipeline(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        
        // Phase-10: Early Infrastructure Bind
        ModelManager.preloadAll(this)
        
        // Elite Optimization Layer: Start hardware profiling immediately
        DelegateBenchmark.performBenchmark(this)

        // Global Native/Java Crash Handler
        // Global Native/Java Crash Handler
        val defaultHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            android.util.Log.e("GlobalCrashHandler", "Uncaught Exception: ${throwable.message}", throwable)
            try {
                // Ensure infrastructure is available for recovery
                ModelManager.preloadAll(this.applicationContext)
                val recoveryManager = ModelManager.recoveryManager
                recoveryManager.enableSafeMode()
                if (recoveryManager.isRecoverable(throwable as Exception)) {
                    android.util.Log.i("GlobalCrashHandler", "Recoverable error logged.")
                }
            } catch (e: Exception) {
                android.util.Log.e("GlobalCrashHandler", "Failed to log crash", e)
            }
            
            // Forward to default handler (safely kills process) instead of hard System.exit
            defaultHandler?.uncaughtException(thread, throwable)
        }

        // Phase-10: Preloading removed from boot to prevent ANR/UI Overload
        // Models now load on-demand when 'Process' is tapped.

        setContent {
            MyApplicationTheme {
                var showSplash by remember { mutableStateOf(true) }

                androidx.compose.animation.AnimatedContent<Boolean>(
                    targetState = showSplash,
                    transitionSpec = {
                        androidx.compose.animation.fadeIn(animationSpec = tween(1000)) togetherWith
                        androidx.compose.animation.fadeOut(animationSpec = tween(800))
                    },
                    label = "splashTransition"
                ) { showSplashState ->
                    if (showSplashState) {
                        SplashScreen(onAnimationFinished = { showSplash = false })
                    } else {
                        AuthGate(dubbingPipeline)
                    }
                }
            }
        }
    }
    override fun onDestroy() {
        super.onDestroy()
        if (isFinishing) {
            try {
                dubbingPipeline.videoProcessor.release()
            } catch(e: Exception) {}
        }
    }
}

@Composable
fun AuthGate(dubbingPipeline: DubbingPipeline) {
    var sessionStatus by remember { mutableStateOf<SessionStatus>(SessionStatus.LoadingFromStorage) }
    val scope = rememberCoroutineScope()
    var isShowingSignup by remember { mutableStateOf(false) }
    var otpEmail by remember { mutableStateOf<String?>(null) }
    var isDarkMode by remember { mutableStateOf(true) }
    var isGuestMode by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        launch {
            kotlinx.coroutines.delay(5000)
            if (sessionStatus is SessionStatus.LoadingFromStorage) {
                sessionStatus = SessionStatus.NotAuthenticated(isSignOut = false)
            }
        }
        AppAuth.client.auth.sessionStatus.collect { status ->
            sessionStatus = status
        }
    }

    val bgColor = if (isDarkMode) Color(0xFF000000) else Color(0xFFFFFFFF)

    if (isGuestMode) {
        MainAppEntry(
            dubbingPipeline = dubbingPipeline,
            initialIsDarkMode = isDarkMode,
            onThemeToggle = { isDarkMode = it },
            onLogout = { isGuestMode = false }
        )
    } else {
        when (sessionStatus) {
            is SessionStatus.LoadingFromStorage -> {
                Box(modifier = Modifier.fillMaxSize().background(bgColor), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
            }
            is SessionStatus.Authenticated -> {
                MainAppEntry(
                    dubbingPipeline = dubbingPipeline,
                    initialIsDarkMode = isDarkMode,
                    onThemeToggle = { isDarkMode = it },
                    onLogout = { scope.launch { AppAuth.signOut() } }
                )
            }
            else -> {
                when {
                    isShowingSignup -> SignupScreen(isDarkMode = isDarkMode, onSignupSuccess = { email -> otpEmail = email; isShowingSignup = false }, onNavigateToLogin = { isShowingSignup = false })
                    else -> LoginScreen(isDarkMode = isDarkMode, onLoginSuccess = { /* handled by sessionStatus */ }, onNavigateToSignup = { isShowingSignup = true }, onGuestLogin = { isGuestMode = true })
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppEntry(
    dubbingPipeline: DubbingPipeline,
    initialIsDarkMode: Boolean,
    onThemeToggle: (Boolean) -> Unit,
    onLogout: () -> Unit
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var videoUri by remember { mutableStateOf<android.net.Uri?>(null) }
    var videoUrl by remember { mutableStateOf("") }
    var targetLanguage by remember { mutableStateOf("Hindi") }
    var isProcessing by remember { mutableStateOf(false) }
    var processingProgress by remember { mutableFloatStateOf(0f) }
    var processingStage by remember { mutableStateOf("") }
    var isDarkMode by remember { mutableStateOf(initialIsDarkMode) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var dubbedAudioUri by remember { mutableStateOf<android.net.Uri?>(null) }
    var dubbedVideoUri by remember { mutableStateOf<android.net.Uri?>(null) }
    var showDubbed by remember { mutableStateOf(false) }
    var isFullscreen by remember { mutableStateOf(false) }
    var liveFrame by remember { mutableStateOf<android.graphics.Bitmap?>(null) }
    var aiReady by remember { mutableStateOf(ModelManager.isReady()) }
    val snackbarHostState = remember { SnackbarHostState() }

    // Polling for AI readiness (Safe, low-frequency)
    LaunchedEffect(Unit) {
        while (!aiReady) {
            kotlinx.coroutines.delay(1000)
            aiReady = ModelManager.isReady()
        }
    }
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    val languages = listOf(
        "English", "Hindi", "Bengali", "Telugu", "Marathi", "Tamil", "Gujarati",
        "Urdu", "Kannada", "Odia", "Malayalam", "Punjabi", "Sanskrit",
        "Assamese", "Maithili", "Santali", "Kashmiri", "Nepali", "Konkani",
        "Sindhi", "Dogri", "Manipuri", "Bodo", "Japanese", "Spanish",
        "French", "German", "Korean", "Russian"
    )

    val videoLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) videoUri = uri
    }

    // Launcher to import model files from storage
    val importModelsLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris != null && uris.isNotEmpty()) {
            scope.launch {
                val modelsDir = java.io.File(context.filesDir, "models")
                if (!modelsDir.exists()) modelsDir.mkdirs()
                var imported = 0
                for (u in uris) {
                    try {
                        val name = u.lastPathSegment?.substringAfterLast('/') ?: "model_${System.currentTimeMillis()}"
                        val outFile = java.io.File(modelsDir, name)
                        context.contentResolver.openInputStream(u)?.use { ins ->
                            outFile.outputStream().use { os -> ins.copyTo(os) }
                        }
                        imported++
                    } catch (e: Exception) {
                        android.util.Log.e("MainActivity", "Failed to import model: ${e.message}")
                    }
                }
                snackbarHostState.showSnackbar("Imported $imported model(s) to app/models/")
            }
        }
    }

    MyApplicationTheme(darkTheme = isDarkMode) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { },
                    navigationIcon = {
                        IconButton(onClick = { scope.launch { drawerState.open() } }) {
                            Icon(Icons.Default.Menu, contentDescription = "Menu")
                        }
                    },
                    actions = {
                        IconButton(onClick = { 
                            isDarkMode = !isDarkMode
                            onThemeToggle(isDarkMode)
                        }) {
                            Icon(if (isDarkMode) Icons.Default.LightMode else Icons.Default.DarkMode, "Theme")
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
                )
            },
            snackbarHost = { SnackbarHost(snackbarHostState) }
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(it)
                    .padding(horizontal = if (isFullscreen) 0.dp else 24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                if (!isFullscreen) {
                    Spacer(Modifier.height(40.dp))

                    Text("Hi ", style = MaterialTheme.typography.headlineLarge.copy(fontWeight = FontWeight.Bold))
                    Text("Where should we start?", style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.SemiBold))

                    Spacer(Modifier.height(48.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth().padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = { videoLauncher.launch("video/*") }) {
                            Icon(Icons.Default.Add, "Upload")
                        }

                        TextField(
                            value = videoUri?.lastPathSegment ?: videoUrl,
                            onValueChange = { videoUrl = it },
                            placeholder = { Text("Paste video URL here...") },
                            modifier = Modifier.weight(1f)
                        )

                        if (videoUri != null) {
                            IconButton(onClick = { videoUri = null }) {
                                Icon(Icons.Default.Close, "Clear")
                            }
                        }
                    }

                    Spacer(Modifier.height(24.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        LanguageDropdown("Target Language", targetLanguage, languages, isDarkMode, Modifier.weight(1f)) { targetLanguage = it }
                    }

                    Spacer(Modifier.height(32.dp))

                    Button(
                        onClick = {
                            // if (!aiReady) return@Button // ALLOW ON-DEMAND LOADING
                            scope.launch {
                                android.util.Log.i("MainActivity", "ProcessVideo_Clicked (Turbo Streaming)")
                                isProcessing = true
                                errorMessage = null
                                liveFrame = null
                                
                                val streamingPlayer = StreamingAudioPlayer()
                                try {
                                    processingStage = "Loading AI models…"
                                    kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Default) {
                                        ModelManager.loadDubbingModels(context)
                                        ModelManager.awaitReadiness(context)
                                    }
                                    streamingPlayer.play()
                                    android.util.Log.i("MainActivity","Models READY — pipeline starting")
                                    val stream = when {
                                        videoUri != null -> dubbingPipeline.processVideoStreaming(videoUri.toString(), targetLanguage)
                                        videoUrl.isNotEmpty() -> dubbingPipeline.processVideoStreaming(videoUrl, targetLanguage)
                                        else -> throw Exception("No video source selected")
                                    }
                                    
                                    var finalAudio = ByteArray(0)
                                    var finalVideoPath: String? = null
                                    
                                    stream.collect { chunk ->
                                        // 1. Update UI (Main Thread)
                                        processingProgress = chunk.progress
                                        processingStage = chunk.message ?: processingStage
                                        if (chunk.visualFrame != null) {
                                            liveFrame = chunk.visualFrame
                                        }
                                        
                                        // 2. Heavy Data Handling (OFF-MAIN THREAD)
                                        kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Default) {
                                            // 🧪 ANR Guard: Log current thread to ensure we aren't blocking UI
                                            if (chunk.audioData.isNotEmpty()) {
                                                android.util.Log.v("MainActivity", "Streaming Chunk Processed on ${Thread.currentThread().name}")
                                                streamingPlayer.write(chunk.audioData)
                                            }
                                        }
                                        
                                        if (chunk.isFinal) {
                                            finalAudio = chunk.audioData
                                            if (chunk.message != null && chunk.message.contains("/")) {
                                                finalVideoPath = chunk.message
                                            }
                                        }
                                    }
                                    
                                    // Processing Complete
                                    streamingPlayer.release()
                                    liveFrame = null
                                    
                                    val (audioUri, videoResultUri) = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                                        val tempAudioFile = File.createTempFile("dubbed_audio_", ".wav", context.cacheDir)
                                        // We might have the full audio in final chunk
                                        if (finalAudio.isNotEmpty()) {
                                            tempAudioFile.writeBytes(dubbingPipeline.addWavHeaderLocal(finalAudio, 16000, 1))
                                        }
                                        
                                        val vUri = finalVideoPath?.let { android.net.Uri.fromFile(File(it)) }
                                        android.net.`Uri`.fromFile(tempAudioFile) to vUri
                                    }
                                    dubbedAudioUri = audioUri
                                    dubbedVideoUri = videoResultUri
                                    
                                    if (videoResultUri != null) {
                                        showDubbed = true // Auto-switch to dubbed video if render succeeded
                                        android.util.Log.i("MainActivity", "Pipeline returned processed video: $videoResultUri")
                                    }
                                    
                                    // 🎯 DUBBING COMPLETED: Final Success Signals
                                    kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                                        android.widget.Toast.makeText(context, "DUBBING COMPLETED", android.widget.Toast.LENGTH_SHORT).show()
                                        // Auto-play the final wav ONLY if video wasn't generated to avoid double audio
                                        if (videoResultUri == null) {
                                            playAudioFile(context, File(audioUri.path ?: ""))
                                        }
                                    }
                                } catch (e: Exception) {
                                    android.util.Log.e("MainActivity", "Processing failed", e)
                                    errorMessage = "Error: ${e.toString()}"
                                    streamingPlayer.release()
                                } finally {
                                    isProcessing = false
                                }
                            }
                        },
                        enabled = (videoUri != null || videoUrl.isNotEmpty()) && !isProcessing, // Removed && aiReady check
                        modifier = Modifier.fillMaxWidth().height(56.dp)
                    ) {
                        Text("PROCESS VIDEO", fontWeight = FontWeight.Bold) // Removed conditional text
                    }



                }

                Spacer(Modifier.height(32.dp))

                Box(
                    modifier = Modifier.fillMaxWidth().weight(1f).clip(RoundedCornerShape(24.dp))
                ) {
                    if (videoUri != null || videoUrl.isNotEmpty()) {
                        SimpleVideoPlayer(
                            uri = videoUri, 
                            url = videoUrl, 
                            dubbedAudioUri = if (showDubbed && dubbedVideoUri == null) dubbedAudioUri else null,
                            dubbedVideoUri = if (showDubbed) dubbedVideoUri else null,
                            playDubbed = showDubbed
                        )

                        if (isProcessing) {
                            Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.5f))) {
                                // LIVE PREVIEW OVERLAY
                                liveFrame?.let { 
                                    androidx.compose.foundation.Image(
                                        bitmap = it.asImageBitmap(),
                                        contentDescription = "Live Preview",
                                        modifier = Modifier.fillMaxSize(),
                                        contentScale = androidx.compose.ui.layout.ContentScale.Fit
                                    )
                                }
                                
                                Column(
                                    modifier = Modifier.fillMaxSize(),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.Center
                                ) {
                                    CircularProgressIndicator(progress = { processingProgress })
                                    Spacer(Modifier.height(16.dp))
                                    Text(processingStage, color = Color.White, style = MaterialTheme.typography.labelLarge)
                                    if (liveFrame != null) {
                                        Text("LIVE PREVIEW ACTIVE", color = Color.Green, style = MaterialTheme.typography.labelSmall)
                                    }
                                }
                            }
                        }
                        
                        if (errorMessage != null) {
                            AlertDialog(
                                onDismissRequest = { errorMessage = null },
                                title = { Text("Processing Failed") },
                                text = { Text(errorMessage ?: "Unknown error") },
                                confirmButton = {
                                    TextButton(onClick = { errorMessage = null }) {
                                        Text("OK")
                                    }
                                },
                                icon = { Icon(Icons.Default.Error, null, tint = MaterialTheme.colorScheme.error) }
                            )
                        }

                        Box(modifier = Modifier.fillMaxSize().padding(16.dp), contentAlignment = Alignment.BottomEnd) {
                            IconButton(onClick = { isFullscreen = !isFullscreen }) {
                                Icon(if (isFullscreen) Icons.Default.FullscreenExit else Icons.Default.Fullscreen, "Fullscreen")
                            }
                        }

                        if (dubbedAudioUri != null || dubbedVideoUri != null) {
                            Box(modifier = Modifier.fillMaxSize().padding(16.dp), contentAlignment = Alignment.BottomStart) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Switch(checked = showDubbed, onCheckedChange = { 
                                        showDubbed = it 
                                        android.util.Log.i("MainActivity", "Switching to ${if(it) "DUBBED" else "ORIGINAL"} source")
                                    })
                                    Spacer(Modifier.width(8.dp))
                                    Text(if(showDubbed) "DUB ON" else "ORIGINAL", color = Color.White, fontWeight = FontWeight.Bold)
                                }
                            }
                        }

                    } else {
                        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.PlayCircle, null, modifier = Modifier.size(80.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun LanguageDropdown(
    label: String,
    selected: String,
    options: List<String>,
    isDarkMode: Boolean,
    modifier: Modifier = Modifier,
    onSelected: (String) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    Column(modifier = modifier) {
        Text(label, style = MaterialTheme.typography.labelMedium)
        Surface(
            onClick = { expanded = true },
            modifier = Modifier.fillMaxWidth().height(52.dp)
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(selected, fontWeight = FontWeight.Bold)
                Icon(if (expanded) Icons.Default.ArrowDropUp else Icons.Default.ArrowDropDown, null)
            }
        }

        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false },
        ) {
            options.forEach { lang ->
                DropdownMenuItem(
                    text = { Text(lang) },
                    onClick = {
                        onSelected(lang)
                        expanded = false
                    }
                )
            }
        }
    }
}


@androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
@Composable
fun SimpleVideoPlayer(
    uri: android.net.Uri?,
    url: String,
    dubbedAudioUri: android.net.Uri? = null,
    dubbedVideoUri: android.net.Uri? = null,
    playDubbed: Boolean = false,
    onWebViewCreated: (android.webkit.WebView) -> Unit = {}
) {
    val context = androidx.compose.ui.platform.LocalContext.current

    val exoPlayer = remember {
        androidx.media3.exoplayer.ExoPlayer.Builder(context).build()
    }

    val dubbedAudioPlayer = remember {
        android.media.MediaPlayer()
    }

    var isReleased by remember { mutableStateOf(false) }

    // Load / update media safely
    LaunchedEffect(uri, url, dubbedVideoUri, playDubbed) {
        if (isReleased) return@LaunchedEffect

        val targetUri = if (playDubbed && dubbedVideoUri != null) {
            dubbedVideoUri
        } else {
            uri
        }

        val mediaItem = targetUri?.let {
            androidx.media3.common.MediaItem.fromUri(it)
        } ?: if (url.startsWith("http")) {
            androidx.media3.common.MediaItem.fromUri(url)
        } else null

        if (mediaItem == null) return@LaunchedEffect

        // Save current position if switching sources
        val currentPos = exoPlayer.currentPosition
        
        exoPlayer.setMediaItem(mediaItem)
        exoPlayer.prepare()
        if (currentPos > 0) exoPlayer.seekTo(currentPos)
        exoPlayer.playWhenReady = true
    }

    // Handle dubbed audio toggle (Only when full dubbed video is NOT used)
    LaunchedEffect(playDubbed, dubbedAudioUri, dubbedVideoUri) {
        if (isReleased) return@LaunchedEffect

        if (playDubbed && dubbedVideoUri == null && dubbedAudioUri != null) {
            // Mute original video and play separate audio
            exoPlayer.volume = 0f
            try {
                dubbedAudioPlayer.reset()
                dubbedAudioPlayer.setDataSource(context, dubbedAudioUri)
                dubbedAudioPlayer.setOnPreparedListener { 
                    it.seekTo(exoPlayer.currentPosition.toInt())
                    it.start() 
                }
                dubbedAudioPlayer.prepareAsync()
            } catch (_: Exception) {
            }

        } else {
            // Unmute original video (or dubbed video which has audio embedded)
            exoPlayer.volume = 1f

            try {
                if (dubbedAudioPlayer.isPlaying) {
                    dubbedAudioPlayer.stop()
                }
            } catch (_: Exception) {
            }
        }
    }

    // Release ONLY ONCE
    DisposableEffect(Unit) {
        onDispose {
            isReleased = true

            try {
                exoPlayer.release()
            } catch (_: Exception) {}

            try {
                dubbedAudioPlayer.release()
            } catch (_: Exception) {}
        }
    }

    AndroidView(
        factory = { ctx ->
            androidx.media3.ui.PlayerView(ctx).apply {
                player = exoPlayer
                useController = true
            }
        }
    )
}

private fun saveVideoToDownloads(context: android.content.Context, sourceFile: java.io.File) {
    val fileName = "TrueAI_Dub_${System.currentTimeMillis()}.mp4"
    val contentValues = android.content.ContentValues().apply {
        put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, fileName)
        put(android.provider.MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH, android.os.Environment.DIRECTORY_DOWNLOADS)
        }
    }
    val uri = context.contentResolver.insert(android.provider.MediaStore.Video.Media.EXTERNAL_CONTENT_URI, contentValues)
    uri?.let { context.contentResolver.openOutputStream(it)?.use { output -> sourceFile.inputStream().copyTo(output) } }
}

@Preview(showSystemUi = true)
@Composable
fun preview1() {
    // Fixed: Do not use LocalContext.current as a parameter value directly in a way that triggers early evaluation.
    // Instead, pass a placeholder if needed or let the inner Composable handle it.
    // For a preview, we can't easily instantiate a real DubbingPipeline.
    Text("Preview Mode: AuthGate UI Check")
}

/**
 * Low-latency AudioTrack wrapper for progressive playback.
 */
class StreamingAudioPlayer {
    private var audioTrack: android.media.AudioTrack? = null
    private val sampleRate = 16000
    private val channelConfig = android.media.AudioFormat.CHANNEL_OUT_MONO
    private val audioFormat = android.media.AudioFormat.ENCODING_PCM_16BIT
    private val bufferSize = android.media.AudioTrack.getMinBufferSize(sampleRate, channelConfig, audioFormat)

    init {
        try {
            audioTrack = android.media.AudioTrack.Builder()
                .setAudioAttributes(android.media.AudioAttributes.Builder()
                    .setUsage(android.media.AudioAttributes.USAGE_MEDIA)
                    .setContentType(android.media.AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build())
                .setAudioFormat(android.media.AudioFormat.Builder()
                    .setEncoding(audioFormat)
                    .setSampleRate(sampleRate)
                    .setChannelMask(channelConfig)
                    .build())
                .setBufferSizeInBytes(bufferSize * 2)
                .setTransferMode(android.media.AudioTrack.MODE_STREAM)
                .build()
        } catch (e: Exception) {
            android.util.Log.e("StreamingAudioPlayer", "Failed to init: ${e.message}")
        }
    }

    fun play() {
        try {
            audioTrack?.play()
        } catch(e: Exception) {}
    }

    fun write(data: ByteArray) {
        try {
            audioTrack?.write(data, 0, data.size)
        } catch(e: Exception) {}
    }

    fun release() {
        try {
            audioTrack?.stop()
            audioTrack?.release()
        } catch(e: Exception) {}
        audioTrack = null
    }
}

/**
 * 🎯 DUB-COMPLETE Helper: Plays the final synthesized WAV file.
 */
private fun playAudioFile(context: android.content.Context, file: java.io.File) {
    if (!file.exists()) return
    try {
        android.media.MediaPlayer().apply {
            setDataSource(file.absolutePath)
            setOnCompletionListener { it.release() }
            prepare()
            start()
        }
    } catch (e: Exception) {
        android.util.Log.e("MainActivity", "Failed to play dubbed audio: ${e.message}")
    }
}
