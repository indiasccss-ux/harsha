package com.example.myapplication

import android.content.Context
import android.util.Log

object ModelChecker {
    private val TAG = "MODEL_CHECKER"

    // Expected asset filenames used by the app (accept common aliases)
    private val expectedModels = listOf(
        "whisper-tiny.tflite",
        "nllb-translator.tflite",
        "demucs-nano.tflite",
        "kokoro-tts.tflite",
        "kokoro-82m.tflite",
        "latentsync-lipsync.tflite",
        "real-esrgan-4k.tflite",
        "real-esrgan.tflite"
    )

    // Returns a map of logical model name -> present
    fun checkAssets(context: Context): Map<String, Boolean> {
        val assets = try {
            context.assets.list("")?.toSet() ?: emptySet()
        } catch (e: Exception) {
            Log.e(TAG, "Failed to list assets: ${e.message}")
            return expectedModels.associateWith { false }
        }

        val results = mutableMapOf<String, Boolean>()
        // For each logical expected name, check any alias match
        val groups = mapOf(
            "whisper" to listOf("whisper-tiny.tflite", "whisper-base.tflite"),
            "translator" to listOf("nllb-translator.tflite", "nllb.tflite"),
            "demucs" to listOf("demucs-nano.tflite", "demucs_v4_nano.tflite"),
            "kokoro" to listOf("kokoro-tts.tflite", "kokoro-82m.tflite", "kokoro.tflite"),
            "latentsync" to listOf("latentsync-lipsync.tflite", "latentsync.tflite"),
            "realesrgan" to listOf("real-esrgan-4k.tflite", "real-esrgan.tflite")
        )

        for ((key, aliases) in groups) {
            val present = aliases.any { assets.contains(it) }
            results[key] = present
        }

        // Also detect Vosk folder
        val hasVosk = assets.any { it.startsWith("vosk-model") }
        results["vosk"] = hasVosk

        Log.i(TAG, "Model asset grouped check: $results")
        return results
    }
}
