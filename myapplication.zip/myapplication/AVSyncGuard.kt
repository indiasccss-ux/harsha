package com.example.myapplication

import android.util.Log

/**
 * A/V Sync Guard (Phase-3 Hardening).
 * Monitors and corrects drift between dubbed audio PTS and video frame PTS.
 * Production target: < 40ms skew.
 */
object AVSyncGuard {
    private const val TAG = "AVSyncGuard"
    private const val DRIFT_THRESHOLD_MS = 120L
    private const val MAX_CORRECTION_MS = 150L

    data class SyncStatus(
        val driftMs: Long,
        val needsCorrection: Boolean,
        val correctionAction: Action = Action.NONE
    )

    enum class Action {
        NONE,
        DROP_FRAME,    // Video leading audio
        DUP_FRAME,     // Video lagging audio
        RESET_PTS      // Drastic drift (> 150ms)
    }

    /**
     * Calculates sync status for the current frame.
     * @param framePtsUs Actual presentation time of the video frame.
     * @param audioTimeUs Expected presentation time based on audio playback/samples.
     */
    fun checkSync(framePtsUs: Long, audioTimeUs: Long): SyncStatus {
        val driftMs = (framePtsUs - audioTimeUs) / 1000
        
        return when {
            Math.abs(driftMs) < DRIFT_THRESHOLD_MS -> {
                SyncStatus(driftMs, false, Action.NONE)
            }
            driftMs > DRIFT_THRESHOLD_MS && driftMs < MAX_CORRECTION_MS -> {
                Log.w(TAG, "A/V Drift: Video Leading by ${driftMs}ms. Dropping frame.")
                SyncStatus(driftMs, true, Action.DROP_FRAME)
            }
            driftMs < -DRIFT_THRESHOLD_MS && driftMs > -MAX_CORRECTION_MS -> {
                Log.w(TAG, "A/V Drift: Video Lagging by ${driftMs}ms. Duplicating frame.")
                SyncStatus(driftMs, true, Action.DUP_FRAME)
            }
            else -> {
                Log.e(TAG, "CRITICAL A/V DRIFT: ${driftMs}ms. Forcing PTS Reset.")
                SyncStatus(driftMs, true, Action.RESET_PTS)
            }
        }
    }

    /**
     * Heuristic for rapid speech synchronization.
     * Increases sensitivity if phonetic density is high.
     */
    fun getAdaptiveThreshold(isRapidSpeech: Boolean): Long {
        return if (isRapidSpeech) 25L else DRIFT_THRESHOLD_MS
    }
}
