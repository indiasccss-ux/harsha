package com.example.myapplication.utils

import android.util.Log

/**
 * PerformanceAnalytics: Additive monitoring utility.
 * 
 * Logs pipeline metrics and telemetry without modifying core logic.
 * Used for production observability and identifying bottlenecks.
 */
object PerformanceAnalytics {
    private const val TAG = "PerformanceAnalytics"
    
    private val latencyMetrics = mutableMapOf<String, Long>()
    
    /**
     * Records the duration of a specific pipeline stage.
     */
    fun logStageLatency(stageName: String, durationMs: Long) {
        latencyMetrics[stageName] = durationMs
        Log.d(TAG, "📊 METRIC [$stageName]: ${durationMs}ms")
        
        if (durationMs > 500) {
            Log.w(TAG, "⚠️ PERFORMANCE WARNING: Stage '$stageName' exceeded 500ms threshold.")
        }
    }

    /**
     * Logs memory usage at peak intervals.
     */
    fun logMemoryPeak(label: String, usedMb: Long) {
        Log.i(TAG, "🧠 MEMORY PEAK [$label]: ${usedMb}MB")
        if (usedMb > 450) {
            Log.w(TAG, "🚨 CRITICAL MEMORY: Exceeded 450MB Peak Target.")
        }
    }

    /**
     * Resets metrics for a new session.
     */
    fun reset() {
        latencyMetrics.clear()
        Log.i(TAG, "Analytics session reset.")
    }
}
