package com.example.myapplication.utils

import android.graphics.Bitmap
import android.graphics.Color
import java.nio.ByteBuffer

/**
 * High-performance Render Utilities for Phase-3 Lip Sync.
 * Approximates YUV <-> ARGB conversion without external native libs.
 */
object RenderUtils {

    /**
     * Optimized YUV420 to ARGB conversion using REUSABLE buffers.
     */
    fun yuvToBitmap(
        yuv: ByteBuffer, 
        width: Int, 
        height: Int,
        outBitmap: Bitmap,
        pixels: IntArray,
        yData: ByteArray,
        uData: ByteArray,
        vData: ByteArray
    ) {
        yuv.rewind()
        yuv.get(yData)
        yuv.get(uData)
        yuv.get(vData)
        
        for (y in 0 until height) {
            val yOffset = y * width
            val uvRowOffset = (y / 2) * (width / 2)
            for (x in 0 until width) {
                val yp = (yData[yOffset + x].toInt() and 0xFF) - 16
                val uvIdx = uvRowOffset + (x / 2)
                val up = (uData[uvIdx].toInt() and 0xFF) - 128
                val vp = (vData[uvIdx].toInt() and 0xFF) - 128
                
                // Fast Integer Math for YUV -> RGB
                // Y' = 1.164(Y-16)
                // R = Y' + 1.596(V-128)
                // G = Y' - 0.391(U-128) - 0.813(V-128)
                // B = Y' + 2.018(U-128)
                val y1164 = 1164 * yp
                var r = (y1164 + 1596 * vp) shr 10
                var g = (y1164 - 400 * up - 813 * vp) shr 10
                var b = (y1164 + 2018 * up) shr 10
                
                r = r.coerceIn(0, 255)
                g = g.coerceIn(0, 255)
                b = b.coerceIn(0, 255)
                
                pixels[yOffset + x] = 0xFF000000.toInt() or (r shl 16) or (g shl 8) or b
            }
        }
        outBitmap.setPixels(pixels, 0, width, 0, 0, width, height)
    }

    /**
     * Optimized ARGB to YUV420 conversion using FAST INTEGER math.
     */
    fun bitmapToYuv(
        bitmap: Bitmap,
        pixels: IntArray,
        outYuv: ByteBuffer
    ) {
        val width = bitmap.width
        val height = bitmap.height
        bitmap.getPixels(pixels, 0, width, 0, 0, width, height)
        
        outYuv.clear()
        
        // Y plane (Fast Integer Math)
        for (i in 0 until width * height) {
            val p = pixels[i]
            val r = (p shr 16) and 0xff; val g = (p shr 8) and 0xff; val b = p and 0xff
            // Y = 0.299R + 0.587G + 0.114B
            val y = ((66 * r + 129 * g + 25 * b + 128) shr 8) + 16
            outYuv.put(y.toByte())
        }
        
        // U & V planes
        for (y in 0 until height step 2) {
            val offset = y * width
            for (x in 0 until width step 2) {
                val p = pixels[offset + x]
                val r = (p shr 16) and 0xff; val g = (p shr 8) and 0xff; val b = p and 0xff
                // U = -0.169R - 0.331G + 0.500B + 128
                val u = ((-38 * r - 74 * g + 112 * b + 128) shr 8) + 128
                outYuv.put(u.toByte())
            }
        }
        for (y in 0 until height step 2) {
            val offset = y * width
            for (x in 0 until width step 2) {
                val p = pixels[offset + x]
                val r = (p shr 16) and 0xff; val g = (p shr 8) and 0xff; val b = p and 0xff
                // V = 0.500R - 0.419G - 0.081B + 128
                val v = ((112 * r - 94 * g - 18 * b + 128) shr 8) + 128
                outYuv.put(v.toByte())
            }
        }
        outYuv.rewind()
    }

    // Legacy wrappers (for non-critical path)
    fun yuvToBitmap(yuv: ByteBuffer, width: Int, height: Int): Bitmap {
        val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        yuvToBitmap(yuv, width, height, bmp, IntArray(width*height), ByteArray(width*height), ByteArray(width*height/4), ByteArray(width*height/4))
        return bmp
    }

    fun bitmapToYuv(bitmap: Bitmap): ByteBuffer {
        val buf = ByteBuffer.allocateDirect(bitmap.width * bitmap.height * 3 / 2)
        bitmapToYuv(bitmap, IntArray(bitmap.width * bitmap.height), buf)
        return buf
    }
}
