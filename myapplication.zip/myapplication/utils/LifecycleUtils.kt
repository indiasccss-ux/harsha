package com.example.myapplication

import android.content.Context
import android.util.Log
import java.io.File

/**
 * ModelLifecycleManager: Strict RAM hygiene for Large Local Models.
 * Ensures only one major model occupies the NPU address space at a time.
 */
object ModelLifecycleManager {

    private val activeModels = mutableSetOf<String>()

    fun load(name: String, action: () -> Unit) {
        if (!activeModels.contains(name)) {
            Log.d("ModelLifecycle", "Activating Model: $name")
            action()
            activeModels.add(name)
        }
    }

    fun unload(name: String, action: () -> Unit) {
        if (activeModels.contains(name)) {
            Log.d("ModelLifecycle", "Deactivating Model: $name (RAM Recovery)")
            action()
            activeModels.remove(name)
            System.gc() // Trigger collection of released mmap buffers
        }
    }
}

/**
 * ArtifactJanitor: Automatic post-render cleanup.
 * Prevents internal storage from ballooning with temporary audio/video chunks.
 */
object ArtifactJanitor {

    fun cleanTemp(context: Context) {
        val cacheCount = context.cacheDir.listFiles()?.count { file ->
            val isTemp = file.name.contains("temp") || 
                         file.name.endsWith(".wav") || 
                         file.name.endsWith(".pcm") ||
                         file.name.endsWith(".png")
            
            if (isTemp) file.delete()
            isTemp
        } ?: 0
        
        Log.i("ArtifactJanitor", "Purged $cacheCount temporary assets from storage.")
    }
}
