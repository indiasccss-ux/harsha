package com.example.myapplication.utils

import java.io.File

object ArtifactJanitor {
    fun clean(vararg files: File?) {
        files.forEach { it?.delete() }
    }
}
