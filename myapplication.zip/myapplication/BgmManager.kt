package com.example.myapplication

import android.util.Log
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.pow
import com.example.myapplication.core.DubbingSegment

/**
 * Manages Background Music (BGM) ducking and mixing.
 * Applies side-chain ducking to background tracks based on speech activity.
 */
object BgmManager {
    private const val TAG = "BgmManager"
    private const val DUCK_LEVEL_DB = -10f // Volume reduction during speech
    private const val FADE_MS = 150        // Cross-fade duration for ducking
    private const val SAMPLE_RATE = 16000

    /**
     * Dims the background audio during speech segments and merges with dubbed vocals.
     * @param backgroundPcm Music/SFX track (16kHz Mono/Stereo).
     * @param dubbedVocalsPcm Full timeline of dubbed vocals (16kHz Mono).
     * @param segments List of speech segments with timing.
     * @return Mixed cinematic audio.
     */
    fun cinematicMix(
        backgroundPcm: ByteArray,
        dubbedVocalsPcm: ByteArray,
        segments: List<DubbingSegment>
    ): ByteArray {
        if (backgroundPcm.isEmpty()) return dubbedVocalsPcm
        
        val bgShorts = pcmToShortArray(backgroundPcm)
        val voxShorts = pcmToShortArray(dubbedVocalsPcm)
        val outShorts = ShortArray(bgShorts.size)

        val duckFactor = 10f.pow(DUCK_LEVEL_DB / 20f)
        val fadeSamples = (FADE_MS * SAMPLE_RATE) / 1000

        // 1. Create Ducking Mask
        val mask = FloatArray(bgShorts.size) { 1.0f }
        for (seg in segments) {
            val startIdx = (seg.start * SAMPLE_RATE).toInt().coerceIn(0, mask.size - 1)
            val endIdx = (seg.end * SAMPLE_RATE).toInt().coerceIn(0, mask.size - 1)
            
            // Apply ducking with fades
            for (i in startIdx until endIdx) {
                mask[i] = duckFactor
            }
            // Linear fade-in
            for (i in 0 until fadeSamples) {
                val idx = startIdx - i
                if (idx >= 0) {
                    val alpha = i.toFloat() / fadeSamples
                    mask[idx] = mask[idx] * alpha + duckFactor * (1 - alpha)
                }
            }
            // Linear fade-out
            for (i in 0 until fadeSamples) {
                val idx = endIdx + i
                if (idx < mask.size) {
                    val alpha = i.toFloat() / fadeSamples
                    mask[idx] = mask[idx] * alpha + duckFactor * (1 - alpha)
                }
            }
        }

        // 2. Perform Mix
        for (i in outShorts.indices) {
            val bg = bgShorts[i] * mask[i]
            val vox = if (i < voxShorts.size) voxShorts[i].toFloat() else 0f
            
            // Saturated Add
            val sum = (bg + vox).toInt()
            outShorts[i] = sum.coerceIn(-32768, 32767).toShort()
        }

        return shortArrayToPcm(outShorts)
    }

    /**
     * Heuristic to detect if a DubbingSegment contains singing.
     * Uses pitch stability (autocorrelation variance) to differentiate 
     * speech from melodic performance.
     */
    fun isSinging(pcm: ByteArray): Boolean {
        if (pcm.size < 3200) return false // Too short to judge
        
        val shorts = pcmToShortArray(pcm)
        val windowSize = 1600 // 100ms
        val pitchHistory = mutableListOf<Float>()
        
        for (i in 0 until shorts.size - windowSize step windowSize) {
            val window = shorts.copyOfRange(i, i + windowSize)
            pitchHistory.add(estimatePitch(window))
        }
        
        // Singing usually has much higher pitch stability (low variance) than speech
        val variance = calculateVariance(pitchHistory)
        Log.d(TAG, "Pitch Variance: $variance")
        
        return variance < 0.15f && pitchHistory.filter { it > 0 }.size > 2
    }

    private fun estimatePitch(window: ShortArray): Float {
        // Simple Autocorrelation for pitch estimation
        var maxCorr = -1f
        var bestLag = -1
        
        for (lag in 40..400) { // Approx 40Hz to 400Hz
            var corr = 0f
            for (i in 0 until window.size - lag) {
                corr += window[i].toFloat() * window[i + lag].toFloat()
            }
            if (corr > maxCorr) {
                maxCorr = corr
                bestLag = lag
            }
        }
        return if (bestLag > 0) SAMPLE_RATE.toFloat() / bestLag else 0f
    }

    private fun calculateVariance(data: List<Float>): Float {
        if (data.isEmpty()) return 0f
        val mean = data.average().toFloat()
        return data.map { (it - mean).pow(2) }.average().toFloat()
    }

    private fun pcmToShortArray(pcm: ByteArray): ShortArray {
        val shorts = ShortArray(pcm.size / 2)
        ByteBuffer.wrap(pcm).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().get(shorts)
        return shorts
    }

    private fun shortArrayToPcm(shorts: ShortArray): ByteArray {
        val pcm = ByteArray(shorts.size * 2)
        ByteBuffer.wrap(pcm).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().put(shorts)
        return pcm
    }
}
